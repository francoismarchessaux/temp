"""
residuals.py
============
Residual PnL analyser — identifies the root causes of PnL error.

After running a backtest, the PnL error on each day is:

    error_t = actual_pnl_t - pca_pnl_t
            = Σ_{i > k} ⟨vega, v_i⟩ · ⟨Δσ_t, v_i⟩   (PC residual)
              + ε_t                                      (noise)

This module decomposes and attributes that residual along multiple axes:

1. **Pillar attribution**   — which expiry/tenor cells drive the error?
2. **Factor attribution**   — how much error would be removed by adding PC k+1?
3. **Temporal clustering**  — are errors clustered (stress regime) or diffuse?
4. **Vega-weighted residual surface** — heatmap of unexplained vega × vol.
5. **Adaptive k suggestion** — what value of k achieves a target R² ?

Usage
-----
    from vol_surface_pca.residuals import ResidualAnalyser

    analyser = ResidualAnalyser(
        changes_df   = changes,
        vega         = vega,
        eigenvectors = model.components,
        eigenvalues  = model.eigenvalues,
        n_std        = 2.0,
    )
    analyser.fit()
    analyser.plot_summary()
"""

from __future__ import annotations

from typing import List, Optional, Tuple

import numpy as np
import pandas as pd

from .diagnostics import (
    build_pc_vector,
    pc_realisation,
    pc_vega_exposure,
    actual_pnl,
    reconstruction_stats,
)
from .data_generator import EXPIRIES, TENORS


# ═══════════════════════════════════════════════════════════════════════════════
class ResidualAnalyser:
    """
    Decompose and attribute PnL errors from a PCA model.

    Parameters
    ----------
    changes_df   : pd.DataFrame (T × n_pillars)
    vega         : array-like (n_pillars,)
    eigenvectors : np.ndarray (n_pillars, n_components)
        Full eigenbasis (ideally all p components, or at least max_k).
    eigenvalues  : np.ndarray (n_components,)
    n_std        : float
    """

    def __init__(
        self,
        changes_df:   pd.DataFrame,
        vega:         np.ndarray,
        eigenvectors: np.ndarray,
        eigenvalues:  np.ndarray,
        n_std:        float = 2.0,
    ):
        self.changes_df   = changes_df
        self.vega         = np.asarray(vega).flatten()
        self.eigenvectors = np.asarray(eigenvectors)
        self.eigenvalues  = np.asarray(eigenvalues)
        self.n_std        = n_std

        self._fitted      = False
        self.pnl_df_:     Optional[pd.DataFrame] = None

    # ── Fit ───────────────────────────────────────────────────────────────────
    def fit(self, k: int = None) -> 'ResidualAnalyser':
        """
        Compute day-by-day PnL attribution for the first k components.

        Parameters
        ----------
        k : int or None
            Number of components to use.  Defaults to all available.
        """
        k    = k or self.eigenvalues.shape[0]
        evec = self.eigenvectors[:, :k]
        eval_ = self.eigenvalues[:k]
        v    = self.vega
        X    = self.changes_df.values

        pcs = [build_pc_vector(evec[:, i], float(eval_[i]), self.n_std)
               for i in range(k)]

        rows = []
        for t in range(X.shape[0]):
            vc   = X[t]
            true = actual_pnl(vc, v)
            pc_pnls = {
                f'pc{i+1}_pnl': pc_realisation(vc, pcs[i]) * pc_vega_exposure(v, pcs[i])
                for i in range(k)
            }
            total = sum(pc_pnls.values())
            # Pillar-level residual: vega_i * (Δσ_i - Δσ_hat_i)
            scores   = evec.T @ vc            # (k,)
            vc_hat   = evec @ scores          # (n_pillars,)
            residual = vc - vc_hat
            pillar_error = v * residual       # (n_pillars,) — per-pillar residual PnL

            rows.append({
                'date':          self.changes_df.index[t],
                'actual_pnl':    true,
                'pca_total_pnl': total,
                'pnl_error':     true - total,
                **pc_pnls,
                '_vc':           vc,
                '_vc_hat':       vc_hat,
                '_residual':     residual,
                '_pillar_error': pillar_error,
            })

        self.pnl_df_ = pd.DataFrame(rows).set_index('date')
        self._k      = k
        self._fitted = True
        return self

    # ── 1. Pillar attribution ─────────────────────────────────────────────────
    def pillar_attribution(self) -> pd.DataFrame:
        """
        Average absolute per-pillar PnL contribution to the residual.

        Returns a (n_expiry × n_tenor) DataFrame of mean |pillar error| in USD.
        """
        self._check_fitted()
        pillar_errors = np.stack(self.pnl_df_['_pillar_error'].values)  # (T, p)
        mean_abs = np.mean(np.abs(pillar_errors), axis=0)
        n_exp, n_ten = len(EXPIRIES), len(TENORS)
        return pd.DataFrame(
            mean_abs.reshape(n_exp, n_ten),
            index=EXPIRIES, columns=TENORS
        )

    def pillar_signed_attribution(self) -> pd.DataFrame:
        """Signed mean per-pillar PnL contribution (reveals systematic biases)."""
        self._check_fitted()
        pillar_errors = np.stack(self.pnl_df_['_pillar_error'].values)
        mean_signed   = np.mean(pillar_errors, axis=0)
        n_exp, n_ten  = len(EXPIRIES), len(TENORS)
        return pd.DataFrame(
            mean_signed.reshape(n_exp, n_ten),
            index=EXPIRIES, columns=TENORS
        )

    # ── 2. Marginal PC contribution ───────────────────────────────────────────
    def marginal_pc_contribution(
        self,
        max_k: Optional[int] = None,
    ) -> pd.DataFrame:
        """
        How much does adding each additional PC reduce PnL RMSE?

        Returns
        -------
        pd.DataFrame with columns: k, rmse, rmse_reduction, explained_ratio
        """
        max_k  = max_k or self.eigenvalues.shape[0]
        v      = self.vega
        X      = self.changes_df.values
        T      = X.shape[0]
        dates  = self.changes_df.index

        rows = []
        prev_rmse = None
        for k in range(0, max_k + 1):
            if k == 0:
                errors    = np.array([actual_pnl(X[t], v) for t in range(T)])
                pnl_total = np.zeros(T)
            else:
                evec  = self.eigenvectors[:, :k]
                eval_ = self.eigenvalues[:k]
                pcs   = [build_pc_vector(evec[:, i], float(eval_[i]), self.n_std)
                         for i in range(k)]
                pnl_total = np.array([
                    sum(pc_realisation(X[t], pcs[i]) * pc_vega_exposure(v, pcs[i])
                        for i in range(k))
                    for t in range(T)
                ])
                errors_raw = np.array([actual_pnl(X[t], v) for t in range(T)])
                errors     = errors_raw - pnl_total

            rmse     = float(np.sqrt((errors**2).mean()))
            true_var = float((np.array([actual_pnl(X[t], v) for t in range(T)])**2).mean())
            expl     = float(1.0 - (errors**2).mean() / true_var) if true_var > 0 else np.nan
            rows.append({
                'k':                k,
                'rmse':             rmse,
                'rmse_reduction':   (prev_rmse - rmse) if prev_rmse is not None else 0.0,
                'explained_ratio':  expl,
            })
            prev_rmse = rmse

        return pd.DataFrame(rows).set_index('k')

    # ── 3. Temporal analysis ──────────────────────────────────────────────────
    def temporal_clustering(self, window: int = 21) -> pd.DataFrame:
        """
        Rolling statistics of the PnL error to detect regime clustering.

        Returns DataFrame with rolling mean, std, and |error| / |actual| ratio.
        """
        self._check_fitted()
        df    = self.pnl_df_[['actual_pnl', 'pca_total_pnl', 'pnl_error']].copy()
        df['abs_error'] = df['pnl_error'].abs()
        df['error_ratio'] = df['abs_error'] / df['actual_pnl'].abs().clip(lower=1.0)

        roll = df[['pnl_error', 'abs_error', 'error_ratio']].rolling(window)
        return pd.DataFrame({
            'rolling_mean_error': roll['pnl_error'].mean(),
            'rolling_std_error':  roll['pnl_error'].std(),
            'rolling_mae':        roll['abs_error'].mean(),
            'rolling_error_ratio':roll['error_ratio'].mean(),
        })

    # ── 4. Adaptive k suggestion ──────────────────────────────────────────────
    def suggest_k(self, target_r2: float = 0.90) -> int:
        """
        Find the smallest k such that the explained ratio ≥ target_r2.

        Parameters
        ----------
        target_r2 : float
            Target in-sample R² (fraction of PnL variance explained by the
            PCA model).

        Returns
        -------
        int : suggested number of components
        """
        mc = self.marginal_pc_contribution()
        above = mc[mc['explained_ratio'] >= target_r2]
        if above.empty:
            return int(mc.index[-1])
        return int(above.index[0])

    # ── 5. Stress / calm decomposition ───────────────────────────────────────
    def stress_decomposition(
        self,
        stress_pct: float = 0.1,
    ) -> pd.DataFrame:
        """
        Split PnL error between stress days (top ``stress_pct`` by |actual_pnl|)
        and calm days, to see if the error is driven by outliers.

        Returns
        -------
        pd.DataFrame with rows ['stress', 'calm', 'all'] and stats columns.
        """
        self._check_fitted()
        df      = self.pnl_df_[['actual_pnl', 'pnl_error']].copy()
        cutoff  = df['actual_pnl'].abs().quantile(1.0 - stress_pct)
        stress  = df[df['actual_pnl'].abs() >= cutoff]
        calm    = df[df['actual_pnl'].abs() < cutoff]

        def stats(d, label):
            err = d['pnl_error']
            return {
                'regime': label,
                'n_days': len(d),
                'mean_error': err.mean(),
                'std_error':  err.std(),
                'rmse':       float(np.sqrt((err**2).mean())),
                'mae':        err.abs().mean(),
            }

        return pd.DataFrame([
            stats(stress, 'stress'),
            stats(calm,   'calm'),
            stats(df,     'all'),
        ]).set_index('regime')

    # ── 6. Plot summary ───────────────────────────────────────────────────────
    def plot_summary(self, figsize=(16, 14)):
        """Generate a 4-panel diagnostic plot."""
        import matplotlib.pyplot as plt
        import matplotlib.ticker as mticker
        import seaborn as sns

        self._check_fitted()
        fig, axes = plt.subplots(2, 2, figsize=figsize)

        # ── Panel 1: Marginal PC contribution ─────────────────────────────
        ax = axes[0, 0]
        mc = self.marginal_pc_contribution()
        ax2 = ax.twinx()
        ax.bar(mc.index[1:], mc['rmse_reduction'].iloc[1:] / 1000,
               color='steelblue', alpha=0.7, label='RMSE reduction')
        ax2.plot(mc.index, mc['explained_ratio'] * 100,
                 color='tomato', marker='o', linewidth=1.5, label='R² (%)')
        ax.set_xlabel('Number of PCs (k)')
        ax.set_ylabel("RMSE reduction ('000 USD)")
        ax2.set_ylabel('Explained Ratio (%)', color='tomato')
        ax.set_title('Marginal Value of Adding Each PC')
        ax.legend(loc='upper left')
        ax2.legend(loc='upper right')

        # ── Panel 2: Pillar attribution heatmap ───────────────────────────
        ax = axes[0, 1]
        pa = self.pillar_attribution()
        sns.heatmap(pa / 1000, ax=ax, cmap='Oranges', annot=True, fmt='.1f',
                    linewidths=0.4, cbar_kws={'label': "Mean |error| ('000 USD)"})
        ax.set_title('Mean |Per-Pillar PnL Error|')

        # ── Panel 3: Error time series ────────────────────────────────────
        ax = axes[1, 0]
        err = self.pnl_df_['pnl_error'] / 1000
        act = self.pnl_df_['actual_pnl'] / 1000
        ax.fill_between(err.index, err, 0, alpha=0.45, color='tomato', label='Error')
        ax.plot(act, linewidth=0.7, color='black', alpha=0.5, label='Actual PnL')
        ax.axhline(0, color='k', linewidth=0.4)
        ax.set_ylabel("PnL ('000 USD)")
        ax.set_title('PnL Error vs Actual PnL Through Time')
        ax.legend(fontsize=8)
        ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f'{x:.0f}k'))

        # ── Panel 4: Stress vs calm decomposition ─────────────────────────
        ax = axes[1, 1]
        sd = self.stress_decomposition()
        metrics = ['rmse', 'mae', 'std_error']
        x = np.arange(len(metrics))
        w = 0.25
        for i, regime in enumerate(['stress', 'calm', 'all']):
            vals = [abs(sd.loc[regime, m]) / 1000 for m in metrics]
            ax.bar(x + i * w, vals, w * 0.9,
                   label=regime, alpha=0.8)
        ax.set_xticks(x + w)
        ax.set_xticklabels([m.upper() for m in metrics])
        ax.set_ylabel("('000 USD)")
        ax.set_title('PnL Error: Stress vs Calm Regime')
        ax.legend()

        plt.suptitle(f'Residual Analysis (k={self._k} PCs)', fontsize=13, y=1.01)
        plt.tight_layout()
        return fig

    # ── Internal ─────────────────────────────────────────────────────────────
    def _check_fitted(self):
        if not self._fitted:
            raise RuntimeError("Call .fit() before accessing results.")
