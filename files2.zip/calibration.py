"""
calibration.py
==============
Hyperparameter optimisation for PCA models via walk-forward grid search.

The objective is to find the model configuration that minimises the OOS
PnL RMSE — the quantity the trader cares about.

Main API
--------
    grid = GridSearch(
        changes_df   = changes,
        vega         = vega,
        param_grid   = {
            'n_components':  [3, 4, 5, 6, 7],
            'window':        [125, 180, 250, 360],
            'cov_estimator': ['sample', 'ledoit_wolf', 'ewma'],
            'half_life':     [60, 120],          # only used when cov='ewma'
        },
        min_train    = 250,
        step_size    = 21,
        metric       = 'rmse',      # or 'mae', 'explained_ratio'
        n_jobs       = 1,
        verbose      = True,
    )
    best = grid.fit()
    print(grid.leaderboard())

Notes
-----
- Grid search uses StaticPCA as the default model class.  The ``window``
  parameter controls which rows are passed to ``fit``; it is separate from
  the ``min_train`` concept in the backtester.
- For rolling or online models, use the ``model_class`` parameter.
- Half-life / lambda are only forwarded when ``cov_estimator='ewma'``.
"""

from __future__ import annotations

import itertools
import time
import traceback
import warnings
from copy import deepcopy
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .pca_models  import StaticPCA, RollingPCA, BasePCA
from .backtesting import WalkForwardBacktest, BacktestResults, summarise_backtests


# ── Helpers ───────────────────────────────────────────────────────────────────
def _expand_grid(param_grid: Dict[str, List]) -> List[Dict]:
    """Cartesian product of parameter lists."""
    keys   = list(param_grid.keys())
    values = list(param_grid.values())
    return [dict(zip(keys, combo)) for combo in itertools.product(*values)]


def _build_static_model_fn(params: dict) -> Callable[[], BasePCA]:
    """Build a StaticPCA factory from a flat params dict."""
    n_comp = params.get('n_components', 5)
    cov    = params.get('cov_estimator', 'sample')
    kwargs = {}
    if cov == 'ewma':
        hl = params.get('half_life', None)
        lm = params.get('lam', None)
        if hl is not None:
            kwargs['half_life'] = hl
        elif lm is not None:
            kwargs['lam'] = lm
        else:
            kwargs['half_life'] = 60
    elif cov == 'factor_model':
        kwargs['n_factors'] = params.get('n_factors', 5)
    elif cov == 'graphical_lasso':
        kwargs['cv'] = params.get('cv', 3)
    return lambda: StaticPCA(n_components=n_comp, cov_estimator=cov, **kwargs)


def _build_rolling_model_fn(params: dict) -> Callable[[], 'RollingWindowAdapter']:
    """Adapter: RollingPCA fitted on just the provided data slice."""
    n_comp  = params.get('n_components', 5)
    window  = params.get('window', 250)
    cov     = params.get('cov_estimator', 'ledoit_wolf')
    kwargs  = {}
    if cov == 'ewma':
        kwargs['half_life'] = params.get('half_life', 60)
    return lambda: RollingWindowAdapter(n_components=n_comp, window=window,
                                        cov_estimator=cov, **kwargs)


class RollingWindowAdapter(BasePCA):
    """
    Wraps ``RollingPCA`` so that ``fit(X)`` uses only the last ``window``
    rows of X, making it compatible with the backtesting engine.
    """
    def __init__(self, n_components=5, window=250, cov_estimator='ledoit_wolf', **kwargs):
        super().__init__(n_components)
        from .pca_models import RollingPCA
        self._rpca = RollingPCA(n_components=n_components, window=window,
                                cov_estimator=cov_estimator, **kwargs)
        self.window = window

    def fit(self, X: np.ndarray) -> 'RollingWindowAdapter':
        # Use only the last `window` rows for the single-snapshot fit
        Xw = X[-self.window:] if X.shape[0] >= self.window else X
        self._rpca.fit(Xw)
        self._components  = self._rpca.components
        self._eigenvalues = self._rpca.eigenvalues
        self._mean        = self._rpca._mean
        return self


# ═══════════════════════════════════════════════════════════════════════════════
# Grid Search
# ═══════════════════════════════════════════════════════════════════════════════
class GridSearch:
    """
    Walk-forward grid search over PCA hyperparameters.

    Parameters
    ----------
    changes_df : pd.DataFrame (T × p)
    vega : np.ndarray (p,)
    param_grid : dict
        Keys map to lists of values to try.  Supported keys for StaticPCA:
            - ``n_components``  : [3, 4, 5, …]
            - ``cov_estimator`` : ['sample', 'ledoit_wolf', 'oas', 'ewma', …]
            - ``half_life``     : [30, 60, 120]   (EWMA only)
            - ``lam``           : [0.94, 0.97]    (EWMA only, alt to half_life)
        Additional keys for rolling models (when model_class='rolling'):
            - ``window``        : [125, 180, 250]
    model_class : str
        ``'static'`` (default) or ``'rolling'``.
    min_train : int
        Minimum training window for the backtester.
    step_size : int
        OOS step size (re-fit frequency).
    window_type : str
        ``'rolling'`` or ``'expanding'`` (backtester window type).
    metric : str
        Objective to minimise: ``'rmse'`` (default), ``'mae'``.
        Or maximise: ``'explained_ratio'``, ``'hit_rate'``.
    maximize : bool
        If True, the metric is maximised (e.g. explained_ratio).
    n_std : float
    verbose : bool
    """

    def __init__(
        self,
        changes_df:  pd.DataFrame,
        vega:        np.ndarray,
        param_grid:  Dict[str, List],
        model_class: str   = 'static',
        min_train:   int   = 250,
        step_size:   int   = 21,
        window_type: str   = 'rolling',
        metric:      str   = 'rmse',
        maximize:    bool  = False,
        n_std:       float = 2.0,
        verbose:     bool  = True,
    ):
        self.changes_df  = changes_df
        self.vega        = vega
        self.param_grid  = param_grid
        self.model_class = model_class.lower()
        self.min_train   = min_train
        self.step_size   = step_size
        self.window_type = window_type
        self.metric      = metric
        self.maximize    = maximize
        self.n_std       = n_std
        self.verbose     = verbose

        self._all_results: List[BacktestResults] = []
        self._leaderboard_df: Optional[pd.DataFrame] = None

    def fit(self) -> BacktestResults:
        """
        Run the grid search.  Returns the best BacktestResults.
        """
        combos     = _expand_grid(self.param_grid)
        n_combos   = len(combos)
        t_start    = time.perf_counter()

        if self.verbose:
            print(f'Grid search: {n_combos} combinations '
                  f'(model={self.model_class}, metric={self.metric})')

        for i, params in enumerate(combos):
            label = ', '.join(f'{k}={v}' for k, v in params.items())
            try:
                if self.model_class == 'static':
                    fn = _build_static_model_fn(params)
                elif self.model_class == 'rolling':
                    fn = _build_rolling_model_fn(params)
                else:
                    raise ValueError(f"Unknown model_class '{self.model_class}'.")

                bt = WalkForwardBacktest(
                    changes_df  = self.changes_df,
                    vega        = self.vega,
                    model_fn    = fn,
                    model_name  = label,
                    config      = params,
                    min_train   = self.min_train,
                    step_size   = self.step_size,
                    window_type = self.window_type,
                    n_std       = self.n_std,
                    verbose     = False,
                )
                with warnings.catch_warnings():
                    warnings.simplefilter('ignore')
                    result = bt.run()
                self._all_results.append(result)

                if self.verbose:
                    score = getattr(result, self.metric) if hasattr(result, self.metric) \
                            else result.summary_dict().get(self.metric, np.nan)
                    print(f'  [{i+1:>3}/{n_combos}]  {label:<55}  '
                          f'{self.metric}={score:,.0f}')

            except Exception as exc:
                if self.verbose:
                    print(f'  [{i+1:>3}/{n_combos}]  {label}  FAILED: {exc}')
                    traceback.print_exc()

        elapsed = time.perf_counter() - t_start
        if self.verbose:
            print(f'\nGrid search completed in {elapsed:.1f}s  '
                  f'({len(self._all_results)} successful runs)')

        return self.best_result

    @property
    def best_result(self) -> Optional[BacktestResults]:
        if not self._all_results:
            return None
        key = lambda r: (
            getattr(r, self.metric)
            if hasattr(r, self.metric)
            else r.summary_dict().get(self.metric, np.nan)
        )
        return min(self._all_results, key=key) if not self.maximize \
               else max(self._all_results, key=key)

    def leaderboard(self, top_n: int = 20) -> pd.DataFrame:
        """
        Return sorted leaderboard of all evaluated configurations.

        Returns
        -------
        pd.DataFrame with one row per configuration, sorted by metric.
        """
        if not self._all_results:
            return pd.DataFrame()
        rows = [r.summary_dict() for r in self._all_results]
        df   = pd.DataFrame(rows)
        if 'model' in df.columns:
            df = df.set_index('model')
        ascending = not self.maximize
        df = df.sort_values(self.metric, ascending=ascending)
        return df.head(top_n)

    def plot_heatmap(
        self,
        row_param:    str,
        col_param:    str,
        metric:       Optional[str] = None,
        ax=None,
    ):
        """
        Plot a 2-D heatmap of ``metric`` over two hyperparameters.

        Parameters
        ----------
        row_param : str   name of the y-axis parameter
        col_param : str   name of the x-axis parameter
        metric    : str   defaults to self.metric
        ax        : matplotlib Axes (optional)
        """
        import matplotlib.pyplot as plt
        import seaborn as sns

        metric = metric or self.metric
        rows   = [r.summary_dict() for r in self._all_results]
        df     = pd.DataFrame(rows)

        if row_param not in df.columns or col_param not in df.columns:
            raise ValueError(f"Parameters {row_param}, {col_param} not found in results.")

        pivot = df.pivot_table(values=metric, index=row_param,
                               columns=col_param, aggfunc='mean')
        if ax is None:
            fig, ax = plt.subplots(figsize=(max(6, pivot.shape[1]*1.5),
                                            max(4, pivot.shape[0]*1.2)))
        sns.heatmap(pivot, ax=ax, cmap='RdYlGn_r', annot=True,
                    fmt='.0f', linewidths=0.5,
                    cbar_kws={'label': metric})
        ax.set_title(f'{metric} heatmap: {row_param} × {col_param}')
        return ax


# ═══════════════════════════════════════════════════════════════════════════════
# Convenience: quick sweep
# ═══════════════════════════════════════════════════════════════════════════════
def quick_sweep(
    changes_df: pd.DataFrame,
    vega:       np.ndarray,
    min_train:  int   = 250,
    step_size:  int   = 21,
    n_std:      float = 2.0,
    verbose:    bool  = True,
) -> GridSearch:
    """
    Run a sensible default grid search covering the most impactful parameters.

    Tries:
        n_components = [3, 4, 5, 6, 7]
        cov_estimator = ['sample', 'ledoit_wolf', 'oas', 'ewma', 'mcd']
        half_life = [60, 120]   (for EWMA only, other estimators ignore this)

    Returns the fitted GridSearch object.
    """
    param_grid = {
        'n_components':  [3, 4, 5, 6, 7],
        'cov_estimator': ['sample', 'ledoit_wolf', 'oas', 'ewma', 'mcd'],
        'half_life':     [60, 120],
    }
    gs = GridSearch(
        changes_df  = changes_df,
        vega        = vega,
        param_grid  = param_grid,
        model_class = 'static',
        min_train   = min_train,
        step_size   = step_size,
        metric      = 'rmse',
        verbose     = verbose,
    )
    gs.fit()
    return gs
