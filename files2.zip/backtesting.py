"""
backtesting.py
==============
Walk-forward backtesting engine for PCA model evaluation.

Supports two paradigms:

1. **Expanding window** – training window grows at each step (more data,
   but slower to adapt to regime changes).
2. **Rolling window**  – fixed-length window slides forward (faster
   adaptation, but discards older data).

At each step the model is re-fitted on the in-sample window and evaluated
on the next ``step_size`` out-of-sample observations.

Main API
--------
    bt = WalkForwardBacktest(
        changes_df   = changes,
        vega         = vega,
        model_fn     = lambda: StaticPCA(5, cov_estimator='ledoit_wolf'),
        min_train    = 250,
        step_size    = 21,        # re-fit monthly
        window_type  = 'rolling', # or 'expanding'
    )
    results = bt.run()
    summary = bt.summary()
"""

from __future__ import annotations

import time
import warnings
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .pca_models  import BasePCA
from .diagnostics import (
    pca_pnl_attribution,
    rolling_pnl_attribution,
    actual_pnl,
)


# ── Result container ──────────────────────────────────────────────────────────
@dataclass
class BacktestResults:
    """Container for a single walk-forward run."""
    model_name:    str
    config:        dict
    pnl_df:        pd.DataFrame   # actual_pnl, pca_total_pnl, pnl_error per OOS day
    fit_times:     List[float]    # seconds per re-fit
    train_windows: List[Tuple]    # (start, end) index of each training window
    oos_windows:   List[Tuple]    # (start, end) index of each OOS window

    # ── Scalar summaries (computed lazily) ───────────────────────────────────
    @property
    def rmse(self) -> float:
        return float(np.sqrt((self.pnl_df['pnl_error']**2).mean()))

    @property
    def mae(self) -> float:
        return float(self.pnl_df['pnl_error'].abs().mean())

    @property
    def mean_error(self) -> float:
        return float(self.pnl_df['pnl_error'].mean())

    @property
    def explained_ratio(self) -> float:
        err = self.pnl_df['pnl_error']
        act = self.pnl_df['actual_pnl']
        denom = (act**2).sum()
        return float(1.0 - (err**2).sum() / denom) if denom > 0 else np.nan

    @property
    def hit_rate(self) -> float:
        """Fraction of days where PCA PnL has the same sign as actual PnL."""
        df = self.pnl_df
        return float((np.sign(df['actual_pnl']) == np.sign(df['pca_total_pnl'])).mean())

    @property
    def avg_fit_time_ms(self) -> float:
        return float(np.mean(self.fit_times) * 1000) if self.fit_times else np.nan

    def summary_dict(self) -> dict:
        return {
            'model':           self.model_name,
            'rmse':            self.rmse,
            'mae':             self.mae,
            'mean_error':      self.mean_error,
            'explained_ratio': self.explained_ratio,
            'hit_rate':        self.hit_rate,
            'avg_fit_ms':      self.avg_fit_time_ms,
            'n_refits':        len(self.fit_times),
            **self.config,
        }


# ── Walk-forward engine ───────────────────────────────────────────────────────
class WalkForwardBacktest:
    """
    Walk-forward (out-of-sample) backtesting for any PCA model.

    Parameters
    ----------
    changes_df : pd.DataFrame (T × n_pillars)
        Daily vol surface changes in bps.
    vega : np.ndarray (n_pillars,)
        Vega sensitivities in USD/bps.
    model_fn : callable → BasePCA
        Factory returning a fresh, unfitted model instance.  Called once per
        re-fit step.  Example: ``lambda: StaticPCA(5, 'ledoit_wolf')``.
    model_name : str
        Label for this run (used in summaries).
    config : dict
        Arbitrary metadata about this run (stored in results).
    min_train : int
        Minimum number of training observations before the first OOS step.
    step_size : int
        Number of OOS observations before the next re-fit.
        - step_size=1  → daily re-fit (expensive but most adaptive)
        - step_size=21 → monthly re-fit
    window_type : str
        ``'rolling'``   – fixed-size training window of length ``min_train``.
        ``'expanding'`` – training window grows at each step.
    n_std : float
        Stress level for PC scenario vectors.
    verbose : bool
    """

    def __init__(
        self,
        changes_df:  pd.DataFrame,
        vega:        np.ndarray,
        model_fn:    Callable[[], BasePCA],
        model_name:  str  = 'model',
        config:      dict = None,
        min_train:   int  = 250,
        step_size:   int  = 21,
        window_type: str  = 'rolling',
        n_std:       float = 2.0,
        verbose:     bool  = False,
    ):
        self.changes_df  = changes_df
        self.vega        = np.asarray(vega).flatten()
        self.model_fn    = model_fn
        self.model_name  = model_name
        self.config      = config or {}
        self.min_train   = min_train
        self.step_size   = step_size
        self.window_type = window_type.lower()
        self.n_std       = n_std
        self.verbose     = verbose

        if self.window_type not in ('rolling', 'expanding'):
            raise ValueError("window_type must be 'rolling' or 'expanding'.")

    def run(self) -> BacktestResults:
        """Execute the full walk-forward loop. Returns a BacktestResults object."""
        X      = self.changes_df.values
        T      = X.shape[0]
        dates  = self.changes_df.index

        all_rows      = []
        fit_times     = []
        train_windows = []
        oos_windows   = []

        t = self.min_train   # pointer: first OOS index

        while t < T:
            # ── Define training window ─────────────────────────────────────
            if self.window_type == 'rolling':
                train_start = t - self.min_train
            else:  # expanding
                train_start = 0
            train_end = t

            # ── Define OOS window ─────────────────────────────────────────
            oos_start = t
            oos_end   = min(t + self.step_size, T)

            X_train = X[train_start:train_end]
            X_oos   = X[oos_start:oos_end]
            d_oos   = dates[oos_start:oos_end]

            # ── Fit model ─────────────────────────────────────────────────
            t0 = time.perf_counter()
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                model = self.model_fn()
                model.fit(X_train)
            elapsed = time.perf_counter() - t0
            fit_times.append(elapsed)
            train_windows.append((train_start, train_end))
            oos_windows.append((oos_start, oos_end))

            if self.verbose:
                print(f'  Fit [{train_start}:{train_end}] → OOS [{oos_start}:{oos_end}]'
                      f'  ({elapsed*1000:.1f} ms)')

            # ── Evaluate on OOS window ─────────────────────────────────────
            evec = model.components
            eval_ = model.eigenvalues
            k    = eval_.shape[0]

            from .diagnostics import build_pc_vector, pc_realisation, pc_vega_exposure
            pcs = [build_pc_vector(evec[:, i], float(eval_[i]), self.n_std)
                   for i in range(k)]

            for day_idx in range(len(d_oos)):
                vc   = X_oos[day_idx]
                date = d_oos[day_idx]
                true = actual_pnl(vc, self.vega)
                pc_pnls = {
                    f'pc{i+1}_pnl': pc_realisation(vc, pcs[i]) * pc_vega_exposure(self.vega, pcs[i])
                    for i in range(k)
                }
                total = sum(pc_pnls.values())
                all_rows.append({
                    'date':          date,
                    'actual_pnl':    true,
                    'pca_total_pnl': total,
                    'pnl_error':     true - total,
                    'train_start':   train_start,
                    'train_end':     train_end,
                    **pc_pnls,
                })

            t += self.step_size

        pnl_df = pd.DataFrame(all_rows).set_index('date')

        return BacktestResults(
            model_name    = self.model_name,
            config        = self.config,
            pnl_df        = pnl_df,
            fit_times     = fit_times,
            train_windows = train_windows,
            oos_windows   = oos_windows,
        )


# ── Multi-model runner ────────────────────────────────────────────────────────
def run_backtests(
    specs:       List[dict],
    changes_df:  pd.DataFrame,
    vega:        np.ndarray,
    min_train:   int   = 250,
    step_size:   int   = 21,
    window_type: str   = 'rolling',
    n_std:       float = 2.0,
    verbose:     bool  = False,
) -> Dict[str, BacktestResults]:
    """
    Run walk-forward backtests for multiple model specifications.

    Parameters
    ----------
    specs : list of dict
        Each dict must have keys ``'name'``, ``'model_fn'``, and optionally
        ``'config'``.

        Example::

            specs = [
                {'name': 'Static/LW',  'model_fn': lambda: StaticPCA(5, 'ledoit_wolf')},
                {'name': 'Static/EWMA','model_fn': lambda: StaticPCA(5, 'ewma', half_life=60)},
            ]

    Returns
    -------
    dict mapping name → BacktestResults
    """
    results = {}
    for spec in specs:
        name = spec['name']
        if verbose:
            print(f'\nRunning: {name}')
        bt = WalkForwardBacktest(
            changes_df  = changes_df,
            vega        = vega,
            model_fn    = spec['model_fn'],
            model_name  = name,
            config      = spec.get('config', {}),
            min_train   = min_train,
            step_size   = step_size,
            window_type = window_type,
            n_std       = n_std,
            verbose     = verbose,
        )
        results[name] = bt.run()
    return results


def summarise_backtests(results: Dict[str, BacktestResults]) -> pd.DataFrame:
    """
    Aggregate summary table for all backtest runs, sorted by RMSE.

    Returns
    -------
    pd.DataFrame indexed by model name.
    """
    rows = [r.summary_dict() for r in results.values()]
    df   = pd.DataFrame(rows).set_index('model')
    return df.sort_values('rmse')
