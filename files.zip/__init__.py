"""
vol_surface_pca
===============
PCA toolkit for swaption ATM normal volatility surfaces.

Quick start
-----------
    from vol_surface_pca import generate_vol_surface_data, StaticPCA, pca_pnl_attribution

    surfaces, changes, vega = generate_vol_surface_data(n_days=500)
    model = StaticPCA(n_components=5, cov_estimator='ledoit_wolf')
    model.fit(changes.values)

    attribution = pca_pnl_attribution(
        vol_changes  = changes.iloc[-1].values,
        vega         = vega.values,
        eigenvectors = model.components,
        eigenvalues  = model.eigenvalues,
        n_std        = 2.0,
    )
    print(attribution)
"""

from .data_generator import (
    generate_vol_surface_data,
    pillar_names,
    surface_to_matrix,
    matrix_to_surface,
    EXPIRIES, TENORS, EXPIRY_YEARS, TENOR_YEARS, N_EXPIRY, N_TENOR, N_PILLARS,
)

from .covariance import (
    SampleCovariance,
    LedoitWolfCovariance,
    OASCovariance,
    EWMACovariance,
    MCDCovariance,
    GraphicalLassoCovariance,
    FactorModelCovariance,
    get_estimator,
    available_estimators,
)

from .stability import (
    fix_sign_flips,
    track_swaps,
    procrustes_align,
    stabilise,
)

from .pca_models import (
    StaticPCA,
    RollingPCA,
    OnlinePCA,
    SparsePCAModel,
    PPCAModel,
    FactorAnalysisModel,
    RobustPCAModel,
    get_model,
    available_models,
)

from .diagnostics import (
    build_pc_vector,
    pc_realisation,
    pc_vega_exposure,
    pc_pnl,
    actual_pnl,
    pca_pnl_attribution,
    rolling_pnl_attribution,
    rolling_pnl_attribution_dynamic,
    compare_models,
    factor_scores,
    reconstruction_stats,
)

__all__ = [
    # data
    'generate_vol_surface_data', 'pillar_names', 'surface_to_matrix',
    'matrix_to_surface', 'EXPIRIES', 'TENORS', 'N_PILLARS',
    # covariance
    'SampleCovariance', 'LedoitWolfCovariance', 'OASCovariance',
    'EWMACovariance', 'MCDCovariance', 'GraphicalLassoCovariance',
    'FactorModelCovariance', 'get_estimator', 'available_estimators',
    # stability
    'fix_sign_flips', 'track_swaps', 'procrustes_align', 'stabilise',
    # models
    'StaticPCA', 'RollingPCA', 'OnlinePCA', 'SparsePCAModel',
    'PPCAModel', 'FactorAnalysisModel', 'RobustPCAModel',
    'get_model', 'available_models',
    # diagnostics
    'build_pc_vector', 'pc_realisation', 'pc_vega_exposure', 'pc_pnl',
    'actual_pnl', 'pca_pnl_attribution', 'rolling_pnl_attribution',
    'rolling_pnl_attribution_dynamic', 'compare_models',
    'factor_scores', 'reconstruction_stats',
]
