"""Hyperparameter sweep:
  - number of factors k = 1..8
  - history window L  = 60, 125, 250, 500, 1250, 2519 days
  - in-sample vs out-of-sample tracking error (rolling, expanding the test set)
  - eigenvector stability vs L (subspace angle to full-sample reference)
"""
import numpy as np
import pandas as pd
import pickle
from numpy.linalg import svd, norm

from data import simulate, vega_book, M, N
import models as mdl

X, Sigma, _ = simulate(T=2520, seed=0)
V = vega_book(seed=1)
v = V.reshape(-1)
T, D = X.shape


def subspace_angle_deg(U1, U2):
    """Largest principal angle (degrees) between column spaces of U1 and U2."""
    Q1, _ = np.linalg.qr(U1)
    Q2, _ = np.linalg.qr(U2)
    s = np.clip(svd(Q1.T @ Q2, compute_uv=False), -1, 1)
    return float(np.degrees(np.arccos(s.min())))


# ---------- 1. R^2 and tracking error vs k, full sample
def fit(model_name, X_sub, Sigma_sub, k):
    if model_name == "abs":
        return mdl.pca_absolute(V, X_sub, Sigma_sub, k)
    if model_name == "rel":
        return mdl.pca_relative(V, X_sub, Sigma_sub, k)
    if model_name == "shrink":
        return mdl.pca_shrinkage(V, X_sub, Sigma_sub, k)
    if model_name == "tucker":
        # rough split keeping k_e * k_t close to k
        if k == 1:   return mdl.pca_tucker(V, X_sub, Sigma_sub, M, N, 1, 1)
        if k <= 2:   return mdl.pca_tucker(V, X_sub, Sigma_sub, M, N, 2, 1)
        if k <= 4:   return mdl.pca_tucker(V, X_sub, Sigma_sub, M, N, 2, 2)
        if k <= 6:   return mdl.pca_tucker(V, X_sub, Sigma_sub, M, N, 3, 2)
        return            mdl.pca_tucker(V, X_sub, Sigma_sub, M, N, 3, 3)
    if model_name == "wgt_v":
        return mdl.pca_weighted(V, X_sub, Sigma_sub, k, w=v ** 2, name="wgt_v")
    raise ValueError(model_name)


def eval_in_sample(res):
    y = X @ V.reshape(-1)
    y = y[res.t_offset:]
    yhat = res.pnl_contribution.sum(1)
    eps = y - yhat
    return float(np.std(eps)), float(1 - np.var(eps) / np.var(y))


print("\n=== R^2 and tracking error vs k (full sample) ===")
rows = []
for name in ["abs", "rel", "shrink", "tucker", "wgt_v"]:
    for k in range(1, 9):
        r = fit(name, X, Sigma, k)
        te, r2 = eval_in_sample(r)
        rows.append({"model": name, "k": k, "tracking_err": te, "R2": r2})
df_k = pd.DataFrame(rows)
piv = df_k.pivot(index="k", columns="model", values="tracking_err")
print("Tracking error ($/day) vs k:")
print(piv.round(0).to_string())
piv2 = df_k.pivot(index="k", columns="model", values="R2")
print("\nR^2 vs k:")
print(piv2.round(4).to_string())

# ---------- 2. Out-of-sample: train on rolling window, eval next 60d
print("\n=== Out-of-sample tracking error vs window length L (k=4) ===")
test_h = 60
rows = []
for L in [60, 125, 250, 500, 1250, 2000]:
    for name in ["abs", "rel", "shrink", "tucker", "wgt_v"]:
        errs = []
        for start in range(0, T - L - test_h, test_h):
            X_tr = X[start:start + L]
            S_tr = Sigma[start:start + L + 1]
            X_te = X[start + L:start + L + test_h]
            S_te = Sigma[start + L:start + L + test_h + 1]
            try:
                r = fit(name, X_tr, S_tr, 4)
            except Exception:
                continue
            # Apply the trained model to the test block
            if name == "rel":
                Urel = r.extras["Urel"]
                sigma_te = S_te[:test_h] if len(S_te) >= test_h else S_te
                Xrel_te = X_te / sigma_te
                F_te = (Xrel_te - Xrel_te.mean(0)) @ Urel
                Beta_t = (v[None, :] * sigma_te) @ Urel
                pnl_te = (F_te * Beta_t).sum(1)
                y_te = X_te @ v
            else:
                F_te = (X_te - X_te.mean(0)) @ r.U
                pnl_te = F_te @ r.beta
                y_te = X_te @ v
            errs.append(np.std(y_te - pnl_te))
        rows.append({"L": L, "model": name, "oos_te_mean": np.mean(errs),
                     "oos_te_p95": np.percentile(errs, 95) if errs else np.nan,
                     "n_blocks": len(errs)})
df_L = pd.DataFrame(rows)
piv_oos = df_L.pivot(index="L", columns="model", values="oos_te_mean")
print("OOS tracking error ($/day), mean over rolling test blocks:")
print(piv_oos.round(0).to_string())

# ---------- 3. Eigenvector stability vs L
print("\n=== Subspace angle (deg) between top-4 PCs trained on window L vs full sample ===")
ref = mdl.pca_absolute(V, X, Sigma, 4)
rows = []
for L in [60, 125, 250, 500, 1250]:
    angles = []
    for start in range(0, T - L, L):
        X_tr = X[start:start + L]
        S_tr = Sigma[start:start + L + 1]
        r = mdl.pca_absolute(V, X_tr, S_tr, 4)
        angles.append(subspace_angle_deg(ref.U, r.U))
    rows.append({"L": L, "mean_angle_deg": np.mean(angles),
                 "max_angle_deg": np.max(angles), "n": len(angles)})
print(pd.DataFrame(rows).round(2).to_string(index=False))

# ---------- 4. Ledoit-Wolf alpha vs window length
print("\n=== Ledoit-Wolf shrinkage intensity alpha vs L ===")
rows = []
for L in [42, 60, 100, 125, 250, 500, 1250, 2000]:
    alphas = []
    for start in range(0, T - L, max(L, 50)):
        _, alpha = mdl._ledoit_wolf(X[start:start + L])
        alphas.append(alpha)
    rows.append({"L": L, "alpha_mean": np.mean(alphas),
                 "alpha_min": np.min(alphas),
                 "alpha_max": np.max(alphas), "n": len(alphas)})
print(pd.DataFrame(rows).round(3).to_string(index=False))

with open("/home/claude/pca_vol/sweep.pkl", "wb") as f:
    pickle.dump({"df_k": df_k, "df_L": df_L}, f)
print("\nSaved sweep.pkl")
