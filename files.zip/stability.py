"""
stability.py
============
Utilities for ensuring eigenvector stability across time in rolling/online PCA.

Problems addressed
------------------
1. **Sign flips**   – eigenvectors are only defined up to a sign; consecutive
   estimates can flip sign arbitrarily.
2. **Eigenvalue swaps** – when two eigenvalues are close, their eigenvectors
   can interchange order across time steps.
3. **Near-degenerate subspace rotation** – when eigenvalues are nearly equal,
   eigenvectors within the degenerate subspace can rotate freely. Procrustes
   alignment handles this as a special case.

Recommended usage order
-----------------------
    1. ``track_swaps``      – reorder new components to best match reference
    2. ``fix_sign_flips``   – correct remaining sign ambiguities
    3. (optionally) ``procrustes_align`` for near-degenerate subspaces
"""

from __future__ import annotations

import numpy as np
from scipy.linalg import orthogonal_procrustes
from scipy.optimize import linear_sum_assignment
from typing import Tuple


# ── 1. Sign-flip correction ───────────────────────────────────────────────────
def fix_sign_flips(
    new_vecs: np.ndarray,
    ref_vecs: np.ndarray,
) -> np.ndarray:
    """
    Flip the sign of each column of ``new_vecs`` so that it has a positive
    inner product with the corresponding column of ``ref_vecs``.

    Parameters
    ----------
    new_vecs : np.ndarray, shape (n_features, n_components)
        Eigenvectors to be corrected.
    ref_vecs : np.ndarray, shape (n_features, n_components)
        Reference eigenvectors (e.g. from previous time step).

    Returns
    -------
    corrected : np.ndarray, same shape as new_vecs
    """
    dot = np.sum(new_vecs * ref_vecs, axis=0)   # (n_components,)
    signs = np.where(dot >= 0, 1.0, -1.0)
    return new_vecs * signs


# ── 2. Swap tracking ──────────────────────────────────────────────────────────
def track_swaps(
    new_vecs:  np.ndarray,
    new_vals:  np.ndarray,
    ref_vecs:  np.ndarray,
    threshold: float = 0.5,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Reorder ``new_vecs`` / ``new_vals`` so that each component best matches
    the ordering of ``ref_vecs``, using the Hungarian algorithm.

    Parameters
    ----------
    new_vecs : np.ndarray, shape (n_features, n_components)
    new_vals : np.ndarray, shape (n_components,)
    ref_vecs : np.ndarray, shape (n_features, n_components)
    threshold : float
        Minimum absolute cosine similarity required to accept a match.
        Components below this threshold are left in their eigenvalue-sorted
        position (no swap is applied for those).

    Returns
    -------
    vecs_reordered : np.ndarray
    vals_reordered : np.ndarray
    perm : np.ndarray of int, shape (n_components,)
        Permutation applied: output[:, i] = new_vecs[:, perm[i]].
    """
    n = new_vecs.shape[1]

    # Cosine similarity (abs) between new PC i and ref PC j
    sim = np.abs(new_vecs.T @ ref_vecs)   # (n, n)

    # Optimal assignment maximising total similarity
    row_ind, col_ind = linear_sum_assignment(-sim)
    # row_ind[k] = which new PC maps to ref position col_ind[k]

    # Build forward permutation: perm[ref_pos] = new_idx
    perm = np.zeros(n, dtype=int)
    for new_idx, ref_pos in zip(row_ind, col_ind):
        if sim[new_idx, ref_pos] >= threshold:
            perm[ref_pos] = new_idx
        else:
            perm[ref_pos] = ref_pos   # keep original order if similarity is low

    return new_vecs[:, perm], new_vals[perm], perm


# ── 3. Procrustes alignment ───────────────────────────────────────────────────
def procrustes_align(
    new_vecs: np.ndarray,
    ref_vecs: np.ndarray,
) -> np.ndarray:
    """
    Find the orthogonal rotation R that minimises
    ‖new_vecs @ R − ref_vecs‖_F  and return ``new_vecs @ R``.

    This simultaneously handles sign flips AND within-subspace rotations
    (most useful when several eigenvalues are close together).

    Parameters
    ----------
    new_vecs : np.ndarray, shape (n_features, n_components)
    ref_vecs : np.ndarray, shape (n_features, n_components)

    Returns
    -------
    aligned : np.ndarray, shape (n_features, n_components)
    """
    R, _ = orthogonal_procrustes(new_vecs, ref_vecs)
    return new_vecs @ R


# ── 4. Composite stabiliser ───────────────────────────────────────────────────
def stabilise(
    new_vecs:  np.ndarray,
    new_vals:  np.ndarray,
    ref_vecs:  np.ndarray,
    ref_vals:  np.ndarray,
    swap_threshold:     float = 0.5,
    degenerate_gap:     float = 0.05,
    use_procrustes:     bool  = True,
) -> Tuple[np.ndarray, np.ndarray, dict]:
    """
    Full stabilisation pipeline: swap tracking → sign correction →
    (optional) Procrustes for near-degenerate pairs.

    Parameters
    ----------
    new_vecs, new_vals : newly computed eigenvectors/eigenvalues
    ref_vecs, ref_vals : reference (previous time step)
    swap_threshold     : min cosine similarity to accept a swap
    degenerate_gap     : relative eigenvalue gap below which Procrustes is used
    use_procrustes     : whether to apply Procrustes on degenerate pairs

    Returns
    -------
    vecs : np.ndarray  – stabilised eigenvectors
    vals : np.ndarray  – reordered eigenvalues
    info : dict        – diagnostics (perm, swaps_detected, degenerate_pairs)
    """
    n = new_vecs.shape[1]

    # Step 1 – reorder
    vecs, vals, perm = track_swaps(new_vecs, new_vals, ref_vecs, swap_threshold)
    swaps_detected = list(perm) != list(range(n))

    # Step 2 – sign correction
    vecs = fix_sign_flips(vecs, ref_vecs)

    # Step 3 – Procrustes within near-degenerate pairs
    degenerate_pairs = []
    if use_procrustes and n >= 2:
        total = vals.sum() if vals.sum() > 0 else 1.0
        for i in range(n - 1):
            gap = abs(vals[i] - vals[i + 1]) / total
            if gap < degenerate_gap:
                degenerate_pairs.append((i, i + 1))
                sub_new = vecs[:, i:i+2]
                sub_ref = ref_vecs[:, i:i+2]
                vecs[:, i:i+2] = procrustes_align(sub_new, sub_ref)

    info = {
        'permutation':       perm,
        'swaps_detected':    swaps_detected,
        'degenerate_pairs':  degenerate_pairs,
    }
    return vecs, vals, info
