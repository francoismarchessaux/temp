"""Run all 5 model variants on the full sample, k=4."""
import numpy as np
import pandas as pd
import pickle

from data import simulate, vega_book, M, N, BUCKETS
import models as mdl
from diagnostics import per_factor_table, per_bucket_table, summary_stats

pd.set_option("display.float_format", lambda x: f"{x:9.3g}")

X, Sigma, L_true = simulate(T=2520, seed=0)
V = vega_book(seed=1)
v = V.reshape(-1)

K = 4
results = {
    "abs":     mdl.pca_absolute(V, X, Sigma, K),
    "rel":     mdl.pca_relative(V, X, Sigma, K),
    "wgt_v":   mdl.pca_weighted(V, X, Sigma, K, w=v ** 2, name="wgt_vega"),
    "shrink":  mdl.pca_shrinkage(V, X, Sigma, K),
    "tucker":  mdl.pca_tucker(V, X, Sigma, M, N, k_e=2, k_t=2),
}
liq = np.ones((M, N)); liq[0, :] = 0.3; liq[-1, :] = 0.4; liq[:, -1] = 0.5
results["wgt_liq"] = mdl.pca_weighted(V, X, Sigma, K, w=liq.reshape(-1),
                                      name="wgt_liq")

print("\n=== Head-to-head summary (full 10y sample, k=4) ===")
summary = pd.DataFrame([summary_stats(V, r, X) for r in results.values()])
print(summary.to_string(index=False))

for key in ["abs", "rel", "shrink", "wgt_v", "wgt_liq", "tucker"]:
    print(f"\n--- per-factor table: {key} ---")
    print(per_factor_table(V, results[key], X).to_string())

print("\n--- per-bucket reliability (absolute PCA, k=4): top-12 by err contrib ---")
pb = per_bucket_table(V, results["abs"], X,
                      [f"{e}x{t}" for (e, t) in BUCKETS])
print(pb.sort_values("pnl_err_var_contrib", ascending=False).head(12).to_string(index=False))

with open("/home/claude/pca_vol/run.pkl", "wb") as f:
    pickle.dump({"X": X, "Sigma": Sigma, "V": V,
                 "results": results, "summary": summary}, f)
print("\nSaved run.pkl")
