"""Diagnostics for evaluating a PCA projection of vega risk."""
import numpy as np
import pandas as pd


def pnl_series(V, X):
    return X @ V.reshape(-1)


def project_pnl(res):
    return res.pnl_contribution.sum(axis=1)


def per_factor_table(V, res, X):
    y = pnl_series(V, X)[res.t_offset:]
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    pnl_i = res.pnl_contribution
    sd_f = res.F.std(0, ddof=1)
    pnl_std_i = pnl_i.std(0, ddof=1)
    var_total = (pnl_std_i ** 2).sum()
    rho = (pnl_std_i ** 2) / max(var_total, 1e-12)
    cum_r2 = []
    cum = np.zeros_like(y)
    for i in range(pnl_i.shape[1]):
        cum = cum + pnl_i[:, i]
        ss_res = float(np.sum((y - cum) ** 2))
        cum_r2.append(1 - ss_res / max(ss_tot, 1e-12))
    return pd.DataFrame({
        "factor_std_bp": sd_f,
        "beta_$/factor": res.beta,
        "pnl_std_$/day": pnl_std_i,
        "rho_book_share": rho,
        "cum_R2_pnl": cum_r2,
    })


def per_bucket_table(V, res, X, bucket_names):
    v = V.reshape(-1)
    Pk = res.U @ res.U.T
    C = (X - X.mean(0)).T @ (X - X.mean(0)) / (len(X) - 1)
    diagC = np.diag(C)
    explained = np.diag(Pk @ C @ Pk)
    residual = np.maximum(diagC - explained, 0.0)
    R2_j = explained / np.maximum(diagC, 1e-12)
    h_j = np.diag(Pk)
    err_contrib = (v ** 2) * residual
    return pd.DataFrame({
        "bucket": bucket_names,
        "vega_$/bp": v,
        "communality_h": h_j,
        "R2_bucket": R2_j,
        "resid_std_bp": np.sqrt(residual),
        "pnl_err_var_contrib": err_contrib,
    })


def summary_stats(V, res, X):
    y = pnl_series(V, X)[res.t_offset:]
    yhat = project_pnl(res)
    eps = y - yhat
    return {
        "model": res.name,
        "k": res.U.shape[1],
        "pnl_std_realised": float(np.std(y)),
        "pnl_std_explained": float(np.std(yhat)),
        "tracking_err": float(np.std(eps)),
        "R2_pnl": float(1 - np.var(eps) / np.var(y)),
        "max_abs_err": float(np.max(np.abs(eps))),
    }
