"""
diagnostics.py
==============
PnL attribution, factor scores, reconstruction quality metrics, and
model comparison utilities for swaption vol surface PCA.

The formulas here replicate and extend the trader's Excel model:

    PC_i realisation  = SUMPRODUCT(vol_changes, pc_i) / SUMSQ(pc_i)
    PC_i vega exposure = SUMPRODUCT(vega, pc_i)
    PC_i PnL          = PC_i realisation × PC_i vega exposure
                      = ⟨Δσ, v_i⟩ · ⟨vega, v_i⟩        (n_std cancels)

    Actual PnL        = SUMPRODUCT(vega, vol_changes)   = ⟨vega, Δσ⟩
    PnL error         = Actual PnL - sum of all PC PnLs
"""

from __future__ import annotations

from typing import Optional, List, Tuple, Dict
import numpy as np
import pandas as pd


# ── Helper ────────────────────────────────────────────────────────────────────
def _to_array(x) -> np.ndarray:
    if isinstance(x, (pd.Series, pd.DataFrame)):
        return x.values
    return np.asarray(x, dtype=float)


# ═══════════════════════════════════════════════════════════════════════════════
# Core attribution functions
# ═══════════════════════════════════════════════════════════════════════════════
def build_pc_vector(
    eigenvector: np.ndarray,
    eigenvalue:  float,
    n_std:       float = 2.0,
) -> np.ndarray:
    """
    Build pc_i = eigenvector_i × √eigenvalue_i × n_std.

    This is the stress vector: the vol surface move corresponding to
    n_std standard deviations along PC_i.

    Parameters
    ----------
    eigenvector : (n_pillars,)  unit-norm eigenvector
    eigenvalue  : scalar        corresponding eigenvalue
    n_std       : float         number of standard deviations for the stress

    Returns
    -------
    pc : (n_pillars,)
    """
    return eigenvector * np.sqrt(max(eigenvalue, 0.0)) * n_std


def pc_realisation(
    vol_changes:  np.ndarray,
    pc_vector:    np.ndarray,
) -> float:
    """
    Compute the realisation of a PC on a given day.

    Excel equivalent: SUMPRODUCT(vol_changes, pc_i) / SUMSQ(pc_i)

    Mathematical interpretation:
        β_i = ⟨Δσ, pc_i⟩ / ‖pc_i‖²
            = ⟨Δσ, v_i⟩ / (√λ_i × n_std)

    This is the OLS coefficient when projecting vol_changes onto pc_i:
    the number of "stress-unit" moves that occurred.

    Parameters
    ----------
    vol_changes : (n_pillars,)   daily vol surface change in bps
    pc_vector   : (n_pillars,)   pc_i vector  (eigenvec × √eigenval × n_std)

    Returns
    -------
    float  (dimensionless: fraction of a stress move)
    """
    vc  = _to_array(vol_changes).flatten()
    pci = _to_array(pc_vector).flatten()
    return float(np.dot(vc, pci) / np.dot(pci, pci))


def pc_vega_exposure(
    vega:      np.ndarray,
    pc_vector: np.ndarray,
) -> float:
    """
    Compute the portfolio's vega exposure to a PC stress move.

    Excel equivalent: SUMPRODUCT(vega, pc_i)

    Mathematical interpretation:
        Φ_i = ⟨vega, pc_i⟩ = ⟨vega, v_i⟩ × √λ_i × n_std

    This is the P&L (in USD) if the vol surface moved by exactly pc_i.

    Parameters
    ----------
    vega      : (n_pillars,)   vega sensitivities in USD/bps
    pc_vector : (n_pillars,)   pc_i vector

    Returns
    -------
    float  (USD)
    """
    v   = _to_array(vega).flatten()
    pci = _to_array(pc_vector).flatten()
    return float(np.dot(v, pci))


def pc_pnl(
    vol_changes:  np.ndarray,
    vega:         np.ndarray,
    pc_vector:    np.ndarray,
) -> float:
    """
    P&L attributed to a single principal component.

        PC_PnL_i = pc_realisation_i × pc_vega_exposure_i
                 = ⟨Δσ, v_i⟩ × ⟨vega, v_i⟩       (n_std and √λ cancel)

    Parameters
    ----------
    vol_changes : (n_pillars,)   daily change in bps
    vega        : (n_pillars,)   USD/bps
    pc_vector   : (n_pillars,)   pc_i

    Returns
    -------
    float  (USD)
    """
    return pc_realisation(vol_changes, pc_vector) * pc_vega_exposure(vega, pc_vector)


def actual_pnl(
    vol_changes: np.ndarray,
    vega:        np.ndarray,
) -> float:
    """
    True P&L: SUMPRODUCT(vega, vol_changes) = ⟨vega, Δσ⟩.

    Parameters
    ----------
    vol_changes : (n_pillars,)
    vega        : (n_pillars,)

    Returns
    -------
    float (USD)
    """
    return float(np.dot(_to_array(vega).flatten(),
                        _to_array(vol_changes).flatten()))


# ═══════════════════════════════════════════════════════════════════════════════
# Full attribution table
# ═══════════════════════════════════════════════════════════════════════════════
def pca_pnl_attribution(
    vol_changes:  np.ndarray,
    vega:         np.ndarray,
    eigenvectors: np.ndarray,
    eigenvalues:  np.ndarray,
    n_std:        float = 2.0,
    pc_labels:    Optional[List[str]] = None,
) -> pd.DataFrame:
    """
    Full PnL attribution across all retained PCs.

    Parameters
    ----------
    vol_changes  : (n_pillars,)       daily vol surface change (bps)
    vega         : (n_pillars,)       vega sensitivities (USD/bps)
    eigenvectors : (n_pillars, k)     columns = eigenvectors
    eigenvalues  : (k,)               corresponding eigenvalues
    n_std        : float              stress level (default 2)
    pc_labels    : list of str        optional names for each PC

    Returns
    -------
    pd.DataFrame with columns:
        pc, eigenvalue, explained_var_pct,
        pc_vector_norm (= √λ × n_std),
        realisation (β_i),
        vega_exposure_usd (Φ_i),
        pc_pnl_usd,
        cumulative_pnl_usd

    Plus summary rows: actual_pnl, pca_pnl (sum), pnl_error.
    """
    vc   = _to_array(vol_changes).flatten()
    v    = _to_array(vega).flatten()
    evec = _to_array(eigenvectors)
    eval = _to_array(eigenvalues)

    k    = eval.shape[0]
    labels = pc_labels or [f'PC{i+1}' for i in range(k)]

    total_ev = eval.sum()
    rows = []
    for i in range(k):
        ev  = float(eval[i])
        pci = build_pc_vector(evec[:, i], ev, n_std)
        r   = pc_realisation(vc, pci)
        phi = pc_vega_exposure(v, pci)
        rows.append({
            'pc':                labels[i],
            'eigenvalue':        ev,
            'explained_var_pct': 100.0 * ev / total_ev if total_ev > 0 else np.nan,
            'pc_vector_norm':    float(np.sqrt(ev) * n_std),
            'realisation':       r,
            'vega_exposure_usd': phi,
            'pc_pnl_usd':        r * phi,
        })

    df = pd.DataFrame(rows).set_index('pc')
    df['cumulative_pnl_usd'] = df['pc_pnl_usd'].cumsum()

    # Summary
    true_pnl  = actual_pnl(vc, v)
    total_pca = df['pc_pnl_usd'].sum()
    error     = true_pnl - total_pca

    summary = pd.DataFrame({
        'pc':                ['— actual —', '— pca_total —', '— error —'],
        'pc_pnl_usd':        [true_pnl, total_pca, error],
        'cumulative_pnl_usd': [np.nan, np.nan, np.nan],
    }).set_index('pc')

    return pd.concat([df, summary])


# ═══════════════════════════════════════════════════════════════════════════════
# Time-series attribution
# ═══════════════════════════════════════════════════════════════════════════════
def rolling_pnl_attribution(
    changes_df:   pd.DataFrame,
    vega:         np.ndarray,
    eigenvectors: np.ndarray,
    eigenvalues:  np.ndarray,
    n_std:        float = 2.0,
) -> pd.DataFrame:
    """
    Compute PnL attribution for every row in ``changes_df``.

    Uses a FIXED set of eigenvectors (from StaticPCA or a snapshot).
    For time-varying eigenvectors (RollingPCA), use
    ``rolling_pnl_attribution_dynamic``.

    Returns
    -------
    pd.DataFrame indexed by date with columns:
        actual_pnl, pc1_pnl, pc2_pnl, …, pca_total_pnl, pnl_error
    """
    k      = eigenvalues.shape[0]
    pcs    = [build_pc_vector(eigenvectors[:, i], eigenvalues[i], n_std)
              for i in range(k)]
    v      = _to_array(vega).flatten()
    rows   = []

    for date, row in changes_df.iterrows():
        vc   = row.values.flatten()
        true = actual_pnl(vc, v)
        pca  = {f'pc{i+1}_pnl': pc_realisation(vc, pcs[i]) * pc_vega_exposure(v, pcs[i])
                for i in range(k)}
        total = sum(pca.values())
        rows.append({'date': date, 'actual_pnl': true,
                     **pca,
                     'pca_total_pnl': total,
                     'pnl_error': true - total})

    return pd.DataFrame(rows).set_index('date')


def rolling_pnl_attribution_dynamic(
    changes_df:          pd.DataFrame,
    vega:                np.ndarray,
    components_history:  List[np.ndarray],
    eigenvalues_history: List[np.ndarray],
    n_std:               float = 2.0,
) -> pd.DataFrame:
    """
    PnL attribution using time-varying eigenvectors from RollingPCA.

    ``components_history[t]`` and ``eigenvalues_history[t]`` must correspond
    to the same date as ``changes_df.iloc[t]``.

    Returns same structure as ``rolling_pnl_attribution``.
    """
    v    = _to_array(vega).flatten()
    rows = []
    n    = min(len(changes_df), len(components_history))

    for t in range(n):
        date  = changes_df.index[t]
        vc    = changes_df.iloc[t].values.flatten()
        evec  = components_history[t]
        eval_ = eigenvalues_history[t]
        k     = eval_.shape[0]

        pcs   = [build_pc_vector(evec[:, i], eval_[i], n_std) for i in range(k)]
        true  = actual_pnl(vc, v)
        pca   = {f'pc{i+1}_pnl': pc_realisation(vc, pcs[i]) * pc_vega_exposure(v, pcs[i])
                 for i in range(k)}
        total = sum(pca.values())
        rows.append({'date': date, 'actual_pnl': true,
                     **pca,
                     'pca_total_pnl': total,
                     'pnl_error': true - total})

    return pd.DataFrame(rows).set_index('date')


# ═══════════════════════════════════════════════════════════════════════════════
# Model comparison
# ═══════════════════════════════════════════════════════════════════════════════
def compare_models(
    results: Dict[str, pd.DataFrame],
    metric:  str = 'pnl_error',
) -> pd.DataFrame:
    """
    Compare multiple models by a scalar metric.

    Parameters
    ----------
    results : dict
        Mapping of model_name → rolling_pnl attribution DataFrame.
    metric : str
        Column to compare (``'pnl_error'``, ``'pca_total_pnl'``, etc.).

    Returns
    -------
    pd.DataFrame with stats per model:
        mean, std, rmse, mae, max_abs_error, explained_ratio
    """
    rows = []
    for name, df in results.items():
        if metric not in df.columns:
            continue
        err  = df[metric].dropna()
        act  = df['actual_pnl'].dropna()
        row  = {
            'model':           name,
            'mean_error':      err.mean(),
            'std_error':       err.std(),
            'rmse':            float(np.sqrt((err**2).mean())),
            'mae':             err.abs().mean(),
            'max_abs_error':   err.abs().max(),
            'explained_ratio': 1.0 - (err**2).sum() / (act**2).sum()
                               if (act**2).sum() > 0 else np.nan,
        }
        rows.append(row)
    return pd.DataFrame(rows).set_index('model').sort_values('rmse')


# ═══════════════════════════════════════════════════════════════════════════════
# Factor score decomposition
# ═══════════════════════════════════════════════════════════════════════════════
def factor_scores(
    changes_df:   pd.DataFrame,
    eigenvectors: np.ndarray,
    eigenvalues:  np.ndarray,
    normalise:    bool = True,
) -> pd.DataFrame:
    """
    Project vol changes onto each PC and return time series of factor scores.

    Parameters
    ----------
    normalise : bool
        If True, divide scores by √eigenvalue so they are in units of σ.

    Returns
    -------
    pd.DataFrame (n_days × k)  with columns PC1 … PCk.
    """
    X    = changes_df.values                        # (n_days, n_pillars)
    evec = _to_array(eigenvectors)                  # (n_pillars, k)
    ev   = _to_array(eigenvalues)

    scores = X @ evec                               # (n_days, k)
    if normalise:
        scores = scores / np.sqrt(np.maximum(ev, 1e-12))

    k      = ev.shape[0]
    labels = [f'PC{i+1}' for i in range(k)]
    return pd.DataFrame(scores, index=changes_df.index, columns=labels)


# ═══════════════════════════════════════════════════════════════════════════════
# Reconstruction quality
# ═══════════════════════════════════════════════════════════════════════════════
def reconstruction_stats(
    X:            np.ndarray,
    eigenvectors: np.ndarray,
    eigenvalues:  np.ndarray,
    pillar_names: Optional[List[str]] = None,
) -> pd.DataFrame:
    """
    Per-pillar reconstruction statistics.

    Returns explained variance per pillar and RMSE of reconstruction residual,
    useful for identifying which surface points the PCA model fits poorly.
    """
    evec   = _to_array(eigenvectors)
    X      = _to_array(X)
    mu     = X.mean(axis=0)
    Xc     = X - mu

    scores = Xc @ evec                              # (n, k)
    Xhat   = scores @ evec.T                        # (n, k)
    resid  = Xc - Xhat                              # (n, p)

    total_var  = np.var(Xc, axis=0)
    resid_var  = np.var(resid, axis=0)
    expl_var   = np.maximum(1.0 - resid_var / np.where(total_var > 0, total_var, 1.0), 0.0)
    rmse       = np.sqrt(np.mean(resid**2, axis=0))

    p = X.shape[1]
    idx = pillar_names or [f'p{i}' for i in range(p)]
    return pd.DataFrame({
        'explained_var':  expl_var,
        'resid_rmse_bps': rmse,
        'total_std_bps':  np.sqrt(total_var),
    }, index=idx)
