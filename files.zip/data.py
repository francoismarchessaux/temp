"""Synthetic swaption ATM normal-vol surface + vega book.

Surface: 7 expiries x 6 tenors = 42 buckets, ~10y daily history.
Vol moves are driven by 4 latent factors + idiosyncratic noise,
with a regime shift halfway through (vol-of-vol roughly doubles)
so window-length analysis is meaningful.
"""
import numpy as np
import pandas as pd

EXPIRIES = ["1M", "3M", "6M", "1Y", "2Y", "5Y", "10Y"]
TENORS = ["1Y", "2Y", "5Y", "10Y", "20Y", "30Y"]
EXP_YEARS = np.array([1/12, 0.25, 0.5, 1.0, 2.0, 5.0, 10.0])
TEN_YEARS = np.array([1.0, 2.0, 5.0, 10.0, 20.0, 30.0])

M, N = len(EXPIRIES), len(TENORS)
D = M * N

BUCKETS = [(e, t) for e in EXPIRIES for t in TENORS]


def base_surface():
    """Realistic-shape ATM normal vol surface in bps."""
    e, t = np.meshgrid(EXP_YEARS, TEN_YEARS, indexing="ij")
    # Higher at short expiry, decays in expiry. Mild hump in tenor.
    vol = 70 + 40 * np.exp(-1.5 * e) + 15 * np.exp(-0.15 * (t - 5) ** 2)
    return vol  # shape (M, N)


def true_loadings():
    """Four latent shape factors over the (expiry, tenor) grid, vectorised.

    Returns L of shape (D, K=4). Columns are the per-bucket loadings of each
    latent factor (in bps per unit factor).
    """
    e, t = np.meshgrid(EXP_YEARS, TEN_YEARS, indexing="ij")
    le = np.log(e + 1e-3)
    lt = np.log(t)

    f1 = np.ones_like(e)                               # parallel level
    f1 *= 1.0 + 0.4 * np.exp(-2 * e)                   # slightly bigger at front
    f2 = (le - le.mean()) / le.std()                   # expiry slope
    f3 = (lt - lt.mean()) / lt.std()                   # tenor slope
    f4 = (le - le.mean()) * (lt - lt.mean())           # twist / fly
    f4 /= np.std(f4)

    # Per-factor amplitudes (bps per unit-std factor)
    amps = np.array([4.5, 2.2, 1.4, 0.9])
    L = np.stack([f1, f2, f3, f4], axis=-1) * amps     # (M, N, K)
    return L.reshape(D, 4)


def simulate(T=2520, seed=0):
    """Daily moves x_t (bps) and a path of ATM vol surfaces (bps).

    Includes a regime shift at T/2 where factor vols ~1.7x.
    """
    rng = np.random.default_rng(seed)
    L = true_loadings()
    K = L.shape[1]

    # Factor scores ~ N(0,1) but with regime shift
    F = rng.standard_normal((T, K))
    scale = np.where(np.arange(T)[:, None] < T // 2, 1.0, 1.7)
    F = F * scale

    # Idiosyncratic noise per bucket
    idio = 0.40 * rng.standard_normal((T, D)) * np.where(
        np.arange(T)[:, None] < T // 2, 1.0, 1.4
    )

    X = F @ L.T + idio   # (T, D)  daily vol changes in bps

    # Build vol path (clip to >5 bps so nothing pathological)
    sigma0 = base_surface().reshape(-1)
    Sigma = np.maximum(5.0, sigma0[None, :] + np.cumsum(X, axis=0) * 0.05)
    return X, Sigma, L


def vega_book(seed=1):
    """Realistic vega book in $/bp.

    Concentrated in 1Y-5Y expiry, 5Y-10Y tenor (typical market-maker book),
    mixed signs, ~$50k/bp peaks, with some near-zero buckets in the wings.
    """
    rng = np.random.default_rng(seed)
    e, t = np.meshgrid(EXP_YEARS, TEN_YEARS, indexing="ij")
    centre = np.exp(-0.5 * (((np.log(e) - 0.0) / 1.2) ** 2 + ((np.log(t) - np.log(7)) / 0.8) ** 2))
    sign = rng.choice([-1, 1], size=(M, N), p=[0.4, 0.6])
    noise = 0.4 + 0.6 * rng.random((M, N))
    V = 50_000 * centre * sign * noise   # $/bp
    # Make wings small
    V[0, -1] *= 0.1
    V[-1, 0] *= 0.1
    return V


if __name__ == "__main__":
    X, Sigma, L = simulate()
    V = vega_book()
    print("X shape", X.shape, "  Sigma shape", Sigma.shape)
    print("Vega book ($/bp), rounded to k:")
    df = pd.DataFrame((V / 1000).round(1), index=EXPIRIES, columns=TENORS)
    print(df)
    print("Total |vega| ($/bp):", round(np.abs(V).sum() / 1000, 1), "k")
    print("Daily PnL std (bps mover * vega):", round(np.std(X @ V.reshape(-1)) / 1000, 1), "k$")
