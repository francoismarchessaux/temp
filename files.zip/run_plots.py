"""All visual diagnostics for the report."""
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import pickle

from data import simulate, vega_book, M, N, EXPIRIES, TENORS
import models as mdl
from diagnostics import per_bucket_table, pnl_series, project_pnl

plt.rcParams.update({"figure.dpi": 110, "font.size": 9, "axes.grid": True,
                     "grid.alpha": 0.3, "axes.spines.top": False,
                     "axes.spines.right": False})

X, Sigma, _ = simulate(T=2520, seed=0)
V = vega_book(seed=1)
v = V.reshape(-1)

K = 4
results = {
    "abs":     mdl.pca_absolute(V, X, Sigma, K),
    "rel":     mdl.pca_relative(V, X, Sigma, K),
    "wgt_v":   mdl.pca_weighted(V, X, Sigma, K, w=v ** 2, name="wgt_v"),
    "shrink":  mdl.pca_shrinkage(V, X, Sigma, K),
    "tucker":  mdl.pca_tucker(V, X, Sigma, M, N, k_e=2, k_t=2),
}

OUT = "/home/claude/pca_vol/plots"
import os; os.makedirs(OUT, exist_ok=True)


# ===== 1. Vega book heatmap
fig, ax = plt.subplots(figsize=(6, 3.5))
im = ax.imshow(V / 1000, cmap="RdBu_r",
               vmin=-V.max() / 1000, vmax=V.max() / 1000, aspect="auto")
ax.set_xticks(range(N)); ax.set_xticklabels(TENORS)
ax.set_yticks(range(M)); ax.set_yticklabels(EXPIRIES)
ax.set_xlabel("tenor"); ax.set_ylabel("expiry")
ax.set_title("Vega book (k$/bp)")
for i in range(M):
    for j in range(N):
        ax.text(j, i, f"{V[i,j]/1000:.0f}", ha="center", va="center",
                fontsize=7, color="black")
plt.colorbar(im, ax=ax, fraction=0.025); plt.tight_layout()
plt.savefig(f"{OUT}/01_vega_book.png", dpi=130, bbox_inches="tight"); plt.close()


# ===== 2. Tracking error vs k (all models)
sweep = pickle.load(open("/home/claude/pca_vol/sweep.pkl", "rb"))
df_k = sweep["df_k"]
fig, ax = plt.subplots(figsize=(7, 4))
for name, grp in df_k.groupby("model"):
    ax.plot(grp["k"], grp["tracking_err"] / 1000, "o-", label=name, lw=1.5)
ax.set_xlabel("number of PCs k"); ax.set_ylabel("in-sample tracking error (k$/day)")
ax.set_title("Tracking error vs k — note vega-weighted blows up at high k")
ax.legend(loc="best"); ax.set_yscale("log")
plt.tight_layout(); plt.savefig(f"{OUT}/02_te_vs_k.png", dpi=130); plt.close()


# ===== 3. OOS tracking error vs window length L
df_L = sweep["df_L"]
fig, ax = plt.subplots(figsize=(7, 4))
for name, grp in df_L.groupby("model"):
    ax.plot(grp["L"], grp["oos_te_mean"] / 1000, "o-", label=name, lw=1.5)
ax.axvline(1260, color="k", ls="--", lw=0.8, alpha=0.5,
           label="regime change at t=1260")
ax.set_xlabel("training window length L (days)")
ax.set_ylabel("out-of-sample tracking error (k$/day)")
ax.set_xscale("log")
ax.set_title("OOS tracking error vs window — long windows worse here\nbecause they straddle a vol regime shift")
ax.legend(loc="best")
plt.tight_layout(); plt.savefig(f"{OUT}/03_te_vs_L.png", dpi=130); plt.close()


# ===== 4. PC loadings heatmaps (absolute PCA, top 4 PCs)
fig, axes = plt.subplots(1, 4, figsize=(12, 3.2))
for i in range(4):
    Ui = results["abs"].U[:, i].reshape(M, N)
    vmax = np.max(np.abs(Ui))
    im = axes[i].imshow(Ui, cmap="RdBu_r", vmin=-vmax, vmax=vmax, aspect="auto")
    axes[i].set_xticks(range(N)); axes[i].set_xticklabels(TENORS, fontsize=7)
    axes[i].set_yticks(range(M)); axes[i].set_yticklabels(EXPIRIES, fontsize=7)
    axes[i].set_title(f"PC{i+1}  σ_f={np.sqrt(results['abs'].extras['lam'][i]):.1f}bp\n"
                      f"β=${results['abs'].beta[i]/1000:.1f}k/factor")
    if i == 0: axes[i].set_ylabel("expiry")
    plt.colorbar(im, ax=axes[i], fraction=0.04)
fig.suptitle("Absolute PCA loadings — interpretable as level / expiry-slope / tenor-slope / twist",
             y=1.02)
plt.tight_layout(); plt.savefig(f"{OUT}/04_loadings_abs.png", dpi=130, bbox_inches="tight")
plt.close()


# ===== 5. Per-bucket R^2 and residual contribution heatmaps
pb = per_bucket_table(V, results["abs"], X,
                      [f"{e}x{t}" for e in EXPIRIES for t in TENORS])
R2_grid = pb["R2_bucket"].values.reshape(M, N)
err_grid = pb["pnl_err_var_contrib"].values.reshape(M, N)
err_grid_std = np.sqrt(err_grid) / 1000  # k$/day std contribution

fig, axes = plt.subplots(1, 2, figsize=(11, 3.6))
im0 = axes[0].imshow(R2_grid * 100, cmap="viridis", aspect="auto", vmin=85, vmax=100)
axes[0].set_title("Per-bucket R² (%) — variance of vol move explained by k=4 factors")
axes[0].set_xticks(range(N)); axes[0].set_xticklabels(TENORS)
axes[0].set_yticks(range(M)); axes[0].set_yticklabels(EXPIRIES)
for i in range(M):
    for j in range(N):
        axes[0].text(j, i, f"{R2_grid[i,j]*100:.1f}", ha="center", va="center",
                     fontsize=7, color="white" if R2_grid[i,j]<0.97 else "black")
plt.colorbar(im0, ax=axes[0], fraction=0.04)

im1 = axes[1].imshow(err_grid_std, cmap="Reds", aspect="auto")
axes[1].set_title("PnL-error std contribution per bucket (k$/day, sqrt scale)")
axes[1].set_xticks(range(N)); axes[1].set_xticklabels(TENORS)
axes[1].set_yticks(range(M)); axes[1].set_yticklabels(EXPIRIES)
for i in range(M):
    for j in range(N):
        axes[1].text(j, i, f"{err_grid_std[i,j]:.0f}", ha="center", va="center",
                     fontsize=7, color="black" if err_grid_std[i,j]<err_grid_std.max()*0.6 else "white")
plt.colorbar(im1, ax=axes[1], fraction=0.04)
plt.tight_layout(); plt.savefig(f"{OUT}/05_per_bucket.png", dpi=130, bbox_inches="tight")
plt.close()


# ===== 6. Realised vs explained PnL time series + residual
y = pnl_series(V, X) / 1000
yhat = project_pnl(results["abs"]) / 1000
eps = y - yhat
fig, axes = plt.subplots(2, 1, figsize=(11, 5), sharex=True,
                         gridspec_kw={"height_ratios": [2, 1]})
ax = axes[0]
ax.plot(y, lw=0.6, color="black", label="realised PnL")
ax.plot(yhat, lw=0.6, color="C1", alpha=0.8, label="explained (k=4)")
ax.axvline(1260, color="k", ls="--", lw=0.8, alpha=0.5, label="regime change")
ax.set_ylabel("PnL (k$/day)"); ax.legend(loc="upper left")
ax.set_title("Realised vs explained PnL — abs PCA, k=4")

ax = axes[1]
ax.plot(eps, lw=0.5, color="C3", label=f"residual (std={np.std(eps):.1f}k$)")
ax.axvline(1260, color="k", ls="--", lw=0.8, alpha=0.5)
ax.set_ylabel("residual (k$)"); ax.set_xlabel("day"); ax.legend(loc="upper left")
ax.set_title("PnL error series — note increased volatility after regime change")
plt.tight_layout(); plt.savefig(f"{OUT}/06_pnl_timeseries.png", dpi=130)
plt.close()


# ===== 7. Cumulative R^2 per book (the rho metric) vs surface variance
res = results["abs"]
lam = res.extras["lam"]
beta = res.beta
surface_var_share = lam / lam.sum()
book_var_share = (lam * beta ** 2) / (lam * beta ** 2).sum()

fig, ax = plt.subplots(figsize=(7, 4))
xpos = np.arange(K)
w = 0.4
ax.bar(xpos - w/2, surface_var_share * 100, w, label="surface variance share",
       color="steelblue")
ax.bar(xpos + w/2, book_var_share * 100, w, label="book PnL variance share (ρ)",
       color="darkorange")
ax.set_xticks(xpos); ax.set_xticklabels([f"PC{i+1}" for i in range(K)])
ax.set_ylabel("variance share (%)")
ax.set_title("Surface variance vs book PnL variance per PC\n"
             "Use the orange bars to decide how many PCs to keep")
ax.legend()
plt.tight_layout(); plt.savefig(f"{OUT}/07_book_vs_surface_share.png", dpi=130)
plt.close()


# ===== 8. Comparison: abs vs vega-weighted PC1 loadings
fig, axes = plt.subplots(1, 2, figsize=(8, 3.3))
for ax, key, title in zip(axes, ["abs", "wgt_v"],
                          ["Absolute PCA — PC1", "Vega-weighted PCA — PC1"]):
    U1 = results[key].U[:, 0].reshape(M, N)
    vmax = np.max(np.abs(U1))
    im = ax.imshow(U1, cmap="RdBu_r", vmin=-vmax, vmax=vmax, aspect="auto")
    ax.set_xticks(range(N)); ax.set_xticklabels(TENORS, fontsize=7)
    ax.set_yticks(range(M)); ax.set_yticklabels(EXPIRIES, fontsize=7)
    ax.set_title(title)
    plt.colorbar(im, ax=ax, fraction=0.04)
fig.suptitle("PC1 shape: vega-weighting biases the 'level' factor toward where the book sits",
             y=1.02)
plt.tight_layout(); plt.savefig(f"{OUT}/08_pc1_compare.png", dpi=130, bbox_inches="tight")
plt.close()


# ===== 9. Ledoit-Wolf alpha vs L
import models as mdl_mod
rows = []
for L in [42, 60, 80, 100, 125, 175, 250, 350, 500, 750, 1250, 2000]:
    alphas = []
    for start in range(0, len(X) - L, max(L, 50)):
        _, alpha = mdl_mod._ledoit_wolf(X[start:start + L])
        alphas.append(alpha)
    rows.append((L, np.mean(alphas), np.percentile(alphas, 5),
                 np.percentile(alphas, 95)))
arr = np.array(rows)
fig, ax = plt.subplots(figsize=(6.5, 3.7))
ax.fill_between(arr[:, 0], arr[:, 2], arr[:, 3], alpha=0.3, color="steelblue",
                label="5–95% across rolling fits")
ax.plot(arr[:, 0], arr[:, 1], "o-", color="steelblue", label="mean")
ax.set_xscale("log"); ax.set_xlabel("window L (days)")
ax.set_ylabel("Ledoit–Wolf shrinkage α")
ax.set_title("Optimal shrinkage intensity vs window length\nLow here (D/T small + high SNR); larger for real surfaces with D≈100")
ax.legend()
plt.tight_layout(); plt.savefig(f"{OUT}/09_lw_alpha.png", dpi=130); plt.close()


print("\nSaved 9 plots to", OUT)
import os; print(sorted(os.listdir(OUT)))
