"""
pca_models.py
=============
PCA model variants for swaption volatility surface analysis.

Models
------
StaticPCA       – PCA on a single fixed historical window.
RollingPCA      – PCA on a sliding window with eigenvector stabilisation.
OnlinePCA       – Sequential online PCA (updates incrementally, one obs at a time).
SparsePCAModel  – Sparse PCA (ℓ1 penalty on loadings for interpretability).
PPCAModel       – Probabilistic PCA via EM (provides uncertainty on factors).
FactorAnalysisModel – Factor Analysis (separate idiosyncratic noise per pillar).
RobustPCAModel  – Iteratively re-weighted PCA (downweights outlier days).

Common interface
----------------
All models expose:

    fit(X)                  – fit on (n_obs × n_features) array
    transform(X)            – project X onto principal components
    fit_transform(X)        – fit then transform
    components              – np.ndarray (n_features, n_components)
    eigenvalues             – np.ndarray (n_components,)
    explained_variance_ratio – np.ndarray (n_components,)
    n_components            – int

RollingPCA additionally exposes:

    fit_rolling(X, index)   – fit on successive windows, returns time series of PCs
    components_history      – list of (n_features, n_components) arrays, one per step
    stability_log           – list of stability diagnostics per step

OnlinePCA additionally exposes:

    partial_fit(x)          – update with a single new observation
"""

from __future__ import annotations

import warnings
from copy import deepcopy
from typing import Optional, List, Tuple, Dict, Any

import numpy as np
import pandas as pd
from sklearn.decomposition import SparsePCA, FactorAnalysis, IncrementalPCA

from .covariance import BaseCovarianceEstimator, SampleCovariance, get_estimator
from .stability  import stabilise, fix_sign_flips


# ── Helpers ───────────────────────────────────────────────────────────────────
def _eigh_sorted(cov: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Return eigenvalues and eigenvectors of a symmetric matrix,
    sorted in *descending* order of eigenvalue."""
    vals, vecs = np.linalg.eigh(cov)
    idx = np.argsort(vals)[::-1]
    return vals[idx], vecs[:, idx]


def _clip_eigenvalues(vals: np.ndarray, floor: float = 1e-10) -> np.ndarray:
    return np.maximum(vals, floor)


# ── Base class ────────────────────────────────────────────────────────────────
class BasePCA:
    """Abstract base PCA model."""

    def __init__(self, n_components: int = 5):
        self.n_components       = n_components
        self._components        = None   # (n_features, n_components)
        self._eigenvalues       = None
        self._mean              = None

    # ── Core API ──────────────────────────────────────────────────────────────
    def fit(self, X: np.ndarray) -> 'BasePCA':
        raise NotImplementedError

    def transform(self, X: np.ndarray) -> np.ndarray:
        """Project (n_obs × n_features) data onto PC axes.  Returns (n_obs × k)."""
        Xc = X - self._mean
        return Xc @ self._components   # (n_obs, k)

    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        return self.fit(X).transform(X)

    def inverse_transform(self, scores: np.ndarray) -> np.ndarray:
        """Reconstruct from scores (n_obs × k) → (n_obs × n_features)."""
        return scores @ self._components.T + self._mean

    def reconstruction_error(self, X: np.ndarray) -> float:
        """Frobenius norm of residuals after projecting & reconstructing."""
        scores = self.transform(X)
        Xhat   = self.inverse_transform(scores)
        return float(np.linalg.norm(X - Xhat, 'fro'))

    # ── Properties ────────────────────────────────────────────────────────────
    @property
    def components(self) -> np.ndarray:
        return self._components

    @property
    def eigenvalues(self) -> np.ndarray:
        return self._eigenvalues

    @property
    def explained_variance_ratio(self) -> np.ndarray:
        ev = _clip_eigenvalues(self._eigenvalues)
        return ev / ev.sum()

    def __repr__(self) -> str:
        return (f"{self.__class__.__name__}"
                f"(n_components={self.n_components})")


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Static PCA
# ═══════════════════════════════════════════════════════════════════════════════
class StaticPCA(BasePCA):
    """
    PCA on a single fixed historical window with a pluggable covariance
    estimator.

    Parameters
    ----------
    n_components : int
        Number of principal components to retain.
    cov_estimator : BaseCovarianceEstimator or str
        Covariance estimator instance or name string (see covariance.py).
        Defaults to sample covariance.
    cov_kwargs : dict
        Keyword arguments forwarded to ``get_estimator`` if ``cov_estimator``
        is a string.
    """

    def __init__(
        self,
        n_components:  int = 5,
        cov_estimator: BaseCovarianceEstimator | str = 'sample',
        **cov_kwargs,
    ):
        super().__init__(n_components)
        if isinstance(cov_estimator, str):
            self.cov_estimator = get_estimator(cov_estimator, **cov_kwargs)
        else:
            self.cov_estimator = cov_estimator

    def fit(self, X: np.ndarray) -> 'StaticPCA':
        """
        Parameters
        ----------
        X : np.ndarray, shape (n_obs, n_features)
            Historical vol surface changes (bps).
        """
        self._mean = X.mean(axis=0)
        cov        = self.cov_estimator.fit(X)
        vals, vecs = _eigh_sorted(cov)

        self._eigenvalues = _clip_eigenvalues(vals[:self.n_components])
        self._components  = vecs[:, :self.n_components]
        return self

    def __repr__(self) -> str:
        return (f"StaticPCA(n_components={self.n_components}, "
                f"cov={self.cov_estimator})")


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Rolling PCA
# ═══════════════════════════════════════════════════════════════════════════════
class RollingPCA(BasePCA):
    """
    PCA on a sliding window with full eigenvector stability enforcement.

    At each step the window rolls forward by one observation and a new PCA
    is computed.  The stability module then:
        1. Tracks eigenvector swaps (Hungarian matching).
        2. Corrects sign flips (dot-product alignment).
        3. Optionally applies Procrustes for near-degenerate subspaces.

    Parameters
    ----------
    n_components : int
    window : int
        Number of observations in each window.
    cov_estimator : str or BaseCovarianceEstimator
    swap_threshold : float
        Minimum cosine similarity to accept a swap assignment.
    degenerate_gap : float
        Relative eigenvalue gap below which Procrustes is applied.
    use_procrustes : bool
    **cov_kwargs
        Forwarded to the covariance estimator.
    """

    def __init__(
        self,
        n_components:   int = 5,
        window:         int = 250,
        cov_estimator:  BaseCovarianceEstimator | str = 'sample',
        swap_threshold: float = 0.5,
        degenerate_gap: float = 0.05,
        use_procrustes: bool  = True,
        **cov_kwargs,
    ):
        super().__init__(n_components)
        self.window          = window
        self.swap_threshold  = swap_threshold
        self.degenerate_gap  = degenerate_gap
        self.use_procrustes  = use_procrustes

        if isinstance(cov_estimator, str):
            self.cov_estimator = get_estimator(cov_estimator, **cov_kwargs)
        else:
            self.cov_estimator = cov_estimator

        # History
        self.components_history:  List[np.ndarray] = []
        self.eigenvalues_history: List[np.ndarray] = []
        self.stability_log:       List[Dict]        = []
        self.dates_:              Optional[pd.DatetimeIndex] = None

    def fit(self, X: np.ndarray) -> 'RollingPCA':
        """
        Fit on the last ``window`` rows of X.  Primarily for using the model
        on a single snapshot.  For time-series use, prefer ``fit_rolling``.
        """
        if X.shape[0] < self.window:
            raise ValueError(f"Need ≥ {self.window} rows, got {X.shape[0]}.")
        Xw             = X[-self.window:]
        self._mean     = Xw.mean(axis=0)
        cov            = self.cov_estimator.fit(Xw)
        vals, vecs     = _eigh_sorted(cov)
        self._eigenvalues = _clip_eigenvalues(vals[:self.n_components])
        self._components  = vecs[:, :self.n_components]
        return self

    def fit_rolling(
        self,
        X:     np.ndarray,
        index: Optional[pd.DatetimeIndex] = None,
    ) -> 'RollingPCA':
        """
        Run a full rolling PCA through the dataset.

        Parameters
        ----------
        X : np.ndarray, shape (T, n_features)
        index : pd.DatetimeIndex, optional

        After fitting, access results via:
            - self.components_history[t]      – (n_features, n_components)
            - self.eigenvalues_history[t]     – (n_components,)
            - self.stability_log[t]           – diagnostics dict
        """
        T = X.shape[0]
        if T < self.window:
            raise ValueError(f"Need ≥ {self.window} rows, got {T}.")

        self.components_history.clear()
        self.eigenvalues_history.clear()
        self.stability_log.clear()
        self.dates_ = index

        prev_vecs = None
        prev_vals = None

        for t in range(self.window, T + 1):
            Xw        = X[t - self.window: t]
            mu        = Xw.mean(axis=0)
            cov       = self.cov_estimator.fit(Xw)
            vals, vecs = _eigh_sorted(cov)
            vals = _clip_eigenvalues(vals[:self.n_components])
            vecs = vecs[:, :self.n_components]

            if prev_vecs is not None:
                vecs, vals, info = stabilise(
                    vecs, vals, prev_vecs, prev_vals,
                    swap_threshold=self.swap_threshold,
                    degenerate_gap=self.degenerate_gap,
                    use_procrustes=self.use_procrustes,
                )
            else:
                info = {'permutation': np.arange(self.n_components),
                        'swaps_detected': False, 'degenerate_pairs': []}

            self.components_history.append(vecs.copy())
            self.eigenvalues_history.append(vals.copy())
            self.stability_log.append(info)

            prev_vecs = vecs.copy()
            prev_vals = vals.copy()

        # Set final state as the model's current components
        self._components  = self.components_history[-1]
        self._eigenvalues = self.eigenvalues_history[-1]
        self._mean        = X[-self.window:].mean(axis=0)

        return self

    def components_at(self, t: int) -> np.ndarray:
        """Return components at rolling index t (0-indexed from window end)."""
        return self.components_history[t]

    def explained_variance_ratio_history(self) -> np.ndarray:
        """Returns (n_steps, n_components) array of EVR through time."""
        out = []
        for vals in self.eigenvalues_history:
            ev = _clip_eigenvalues(vals)
            out.append(ev / ev.sum())
        return np.array(out)

    def swap_events(self) -> List[Tuple[int, List]]:
        """Return list of (step_index, pairs_swapped) for detected swaps."""
        return [(i, log['permutation'])
                for i, log in enumerate(self.stability_log)
                if log['swaps_detected']]


# ═══════════════════════════════════════════════════════════════════════════════
# 3. Online / Sequential PCA
# ═══════════════════════════════════════════════════════════════════════════════
class OnlinePCA(BasePCA):
    """
    Sequential online PCA that updates its factor model one observation at a time.

    Built on sklearn's ``IncrementalPCA`` (based on the Brand 2006 rank-1
    update algorithm) with stability corrections applied after each update.

    This is appropriate when:
      - Data arrives as a stream and the full history is unavailable.
      - You want the model to continuously adapt to the latest regime.
      - Memory constraints prevent storing the full history.

    Parameters
    ----------
    n_components : int
    batch_size : int
        Minimum batch size for the first fit (warm-up period).
    forgetting_factor : float in (0, 1]
        Weight applied to old covariance before each update.
        1.0 = no forgetting; 0.95 = mild drift; 0.90 = faster adaptation.
    """

    def __init__(
        self,
        n_components:      int   = 5,
        batch_size:        int   = 30,
        forgetting_factor: float = 1.0,
    ):
        super().__init__(n_components)
        self.batch_size        = batch_size
        self.forgetting_factor = forgetting_factor
        self._ipca             = IncrementalPCA(n_components=n_components,
                                                batch_size=batch_size)
        self._initialized      = False
        self._n_seen           = 0
        self.components_history:  List[np.ndarray] = []
        self.eigenvalues_history: List[np.ndarray] = []

    def fit(self, X: np.ndarray) -> 'OnlinePCA':
        """Warm-up: fit on the full array X (treats it as the initial batch)."""
        self._ipca.fit(X)
        self._initialized = True
        self._n_seen      = X.shape[0]
        self._mean        = self._ipca.mean_
        self._sync_from_ipca()
        return self

    def partial_fit(self, x: np.ndarray) -> 'OnlinePCA':
        """
        Update with one or more new observations.

        Parameters
        ----------
        x : np.ndarray, shape (1, n_features) or (n_features,)
        """
        x = np.atleast_2d(x)
        prev_vecs = self._components.copy() if self._components is not None else None
        prev_vals = self._eigenvalues.copy() if self._eigenvalues is not None else None

        # Apply forgetting to singular values before update
        if self.forgetting_factor < 1.0 and self._initialized:
            ff = self.forgetting_factor
            self._ipca.singular_values_ = self._ipca.singular_values_ * ff

        self._ipca.partial_fit(x)
        self._n_seen += x.shape[0]
        self._mean    = self._ipca.mean_
        self._sync_from_ipca()

        # Stabilise against previous estimate
        if prev_vecs is not None and self._initialized:
            vecs, vals, _ = stabilise(
                self._components, self._eigenvalues,
                prev_vecs, prev_vals,
                swap_threshold=0.5, use_procrustes=False,
            )
            self._components  = vecs
            self._eigenvalues = vals

        self._initialized = True
        self.components_history.append(self._components.copy())
        self.eigenvalues_history.append(self._eigenvalues.copy())
        return self

    def fit_sequential(
        self,
        X:            np.ndarray,
        warmup:       Optional[int] = None,
        index:        Optional[pd.DatetimeIndex] = None,
    ) -> 'OnlinePCA':
        """
        Process all rows of X sequentially.

        Parameters
        ----------
        X : (T, n_features)
        warmup : int, optional
            Number of initial rows used for the first batch fit.
            Defaults to ``batch_size``.
        index : pd.DatetimeIndex, optional
        """
        self.components_history.clear()
        self.eigenvalues_history.clear()
        warmup = warmup or self.batch_size

        # Initial batch
        self.fit(X[:warmup])

        # Stream remaining observations one by one
        for t in range(warmup, X.shape[0]):
            self.partial_fit(X[t:t+1])

        return self

    def _sync_from_ipca(self):
        """Copy sklearn IncrementalPCA state into our interface."""
        if hasattr(self._ipca, 'components_'):
            self._components  = self._ipca.components_.T   # (n_features, k)
            sv                = self._ipca.singular_values_
            n                 = self._ipca.n_samples_seen_
            self._eigenvalues = _clip_eigenvalues(sv**2 / max(n - 1, 1))


# ═══════════════════════════════════════════════════════════════════════════════
# 4. Sparse PCA
# ═══════════════════════════════════════════════════════════════════════════════
class SparsePCAModel(BasePCA):
    """
    Sparse PCA: adds an ℓ1 penalty to force most loadings to zero.

    Produces more interpretable eigenvectors: each PC loads only on a
    localised region of the vol surface (e.g. front-end or back-end).
    Useful for identifying localised hedging strategies.

    Caveat: components are NOT orthogonal; explained variance is
    approximate.

    Parameters
    ----------
    n_components : int
    alpha : float
        ℓ1 regularisation strength.  Larger → sparser loadings.
    max_iter : int
    random_state : int
    """

    def __init__(
        self,
        n_components: int = 5,
        alpha:        float = 0.5,
        max_iter:     int   = 500,
        random_state: int   = 42,
    ):
        super().__init__(n_components)
        self.alpha        = alpha
        self.max_iter     = max_iter
        self.random_state = random_state
        self._spca        = SparsePCA(
            n_components=n_components,
            alpha=alpha,
            max_iter=max_iter,
            random_state=random_state,
        )

    def fit(self, X: np.ndarray) -> 'SparsePCAModel':
        self._mean = X.mean(axis=0)
        Xc         = X - self._mean
        self._spca.fit(Xc)

        # Components: (n_components, n_features) → transpose to (n_features, k)
        raw_comps = self._spca.components_.T  # (n_features, k)

        # Normalise columns
        norms = np.linalg.norm(raw_comps, axis=0, keepdims=True)
        norms = np.where(norms < 1e-12, 1.0, norms)
        self._components = raw_comps / norms

        # Approximate eigenvalues from projected variance
        scores = Xc @ self._components
        self._eigenvalues = _clip_eigenvalues(np.var(scores, axis=0))
        return self

    def sparsity(self) -> np.ndarray:
        """Fraction of near-zero loadings per component (|loading| < 1e-4)."""
        return (np.abs(self._components) < 1e-4).mean(axis=0)


# ═══════════════════════════════════════════════════════════════════════════════
# 5. Probabilistic PCA (PPCA) via EM
# ═══════════════════════════════════════════════════════════════════════════════
class PPCAModel(BasePCA):
    """
    Probabilistic PCA via the EM algorithm (Tipping & Bishop 1999).

    Model:   x = W z + μ + ε,   z ~ N(0, I_k),   ε ~ N(0, σ² I_p)

    Advantages over classical PCA:
      - Maximum-likelihood framework; handles missing data naturally.
      - Provides an estimate of isotropic noise σ².
      - Factor scores z have a proper posterior distribution.
      - Log-likelihood can be used for model selection (choosing k).

    Parameters
    ----------
    n_components : int
        Latent dimension k.
    max_iter : int
        Maximum EM iterations.
    tol : float
        Convergence tolerance on log-likelihood.
    random_state : int
    """

    def __init__(
        self,
        n_components: int   = 5,
        max_iter:     int   = 200,
        tol:          float = 1e-6,
        random_state: int   = 42,
    ):
        super().__init__(n_components)
        self.max_iter     = max_iter
        self.tol          = tol
        self.random_state = random_state
        self.sigma2_:     Optional[float] = None
        self.W_:          Optional[np.ndarray] = None
        self.log_likelihoods_: List[float] = []

    def fit(self, X: np.ndarray) -> 'PPCAModel':
        n, p   = X.shape
        k      = self.n_components
        rng    = np.random.default_rng(self.random_state)

        self._mean = X.mean(axis=0)
        Xc         = X - self._mean

        # ── Initialise W and σ² from first k eigenvalues ──────────────────
        S          = (Xc.T @ Xc) / (n - 1)
        vals, vecs = _eigh_sorted(S)
        W          = vecs[:, :k] * np.sqrt(np.maximum(vals[:k] - vals[k:].mean(), 1e-6))
        sigma2     = float(np.maximum(vals[k:].mean(), 1e-6))

        self.log_likelihoods_.clear()

        for _ in range(self.max_iter):
            # ── E-step ────────────────────────────────────────────────────
            M     = W.T @ W + sigma2 * np.eye(k)          # (k, k)
            Minv  = np.linalg.inv(M)
            Ez    = Xc @ W @ Minv.T                        # (n, k)
            Ezz   = n * sigma2 * Minv + Ez.T @ Ez          # (k, k)

            # ── M-step ────────────────────────────────────────────────────
            W_new    = (Xc.T @ Ez) @ np.linalg.inv(Ezz)   # (p, k)
            sigma2_new = (
                np.trace(S)
                - 2 * np.trace(Ez.T @ Xc @ W_new) / n
                + np.trace(Ezz @ W_new.T @ W_new) / n
            ) / p
            sigma2_new = float(np.maximum(sigma2_new, 1e-8))

            # ── Log-likelihood (up to constants) ──────────────────────────
            C     = W_new @ W_new.T + sigma2_new * np.eye(p)
            sign, logdet = np.linalg.slogdet(C)
            if sign <= 0:
                break
            ll = -0.5 * (n * logdet + np.trace(np.linalg.solve(C, S) * n))
            self.log_likelihoods_.append(ll)

            W      = W_new
            sigma2 = sigma2_new

            if len(self.log_likelihoods_) > 1:
                if abs(self.log_likelihoods_[-1] - self.log_likelihoods_[-2]) < self.tol:
                    break

        self.W_      = W
        self.sigma2_ = sigma2

        # ── Derive PC components from W via QR ────────────────────────────
        Q, R = np.linalg.qr(W)                             # (p, k), (k, k)
        self._components = Q                               # orthonormal (p, k)

        # Approximate eigenvalues
        WtW = W.T @ W
        ev  = np.diag(WtW) + sigma2
        self._eigenvalues = _clip_eigenvalues(np.sort(ev)[::-1])

        return self

    def bic(self, X: np.ndarray) -> float:
        """
        Bayesian Information Criterion for model selection over k.
        Lower is better.
        """
        n, p = X.shape
        k    = self.n_components
        n_params = p * k + 1   # W entries + σ²
        ll   = self.log_likelihoods_[-1] if self.log_likelihoods_ else np.nan
        return -2 * ll + n_params * np.log(n)


# ═══════════════════════════════════════════════════════════════════════════════
# 6. Factor Analysis PCA
# ═══════════════════════════════════════════════════════════════════════════════
class FactorAnalysisModel(BasePCA):
    """
    Factor Analysis (FA) — like PPCA but with pillar-specific noise variances.

    Model: x = W z + μ + ε,   ε_i ~ N(0, ψ_i)  (heteroskedastic noise)

    The diagonal noise matrix Ψ is estimated per pillar, allowing some
    surface points to be noisier than others (e.g. far OTM or illiquid
    pillars).

    Parameters
    ----------
    n_components : int
    max_iter : int
    random_state : int
    """

    def __init__(
        self,
        n_components: int = 5,
        max_iter:     int = 500,
        random_state: int = 42,
    ):
        super().__init__(n_components)
        self.max_iter     = max_iter
        self.random_state = random_state
        self._fa          = FactorAnalysis(
            n_components=n_components,
            max_iter=max_iter,
            random_state=random_state,
        )
        self.noise_variance_: Optional[np.ndarray] = None

    def fit(self, X: np.ndarray) -> 'FactorAnalysisModel':
        self._mean = X.mean(axis=0)
        self._fa.fit(X)

        raw_comps            = self._fa.components_.T   # (n_features, k)
        norms                = np.linalg.norm(raw_comps, axis=0, keepdims=True)
        norms                = np.where(norms < 1e-12, 1.0, norms)
        self._components     = raw_comps / norms
        self.noise_variance_ = self._fa.noise_variance_

        Xc = X - self._mean
        scores = Xc @ self._components
        self._eigenvalues = _clip_eigenvalues(np.var(scores, axis=0))
        return self


# ═══════════════════════════════════════════════════════════════════════════════
# 7. Robust (Iteratively Reweighted) PCA
# ═══════════════════════════════════════════════════════════════════════════════
class RobustPCAModel(BasePCA):
    """
    Robust PCA via iteratively reweighted least squares (IRLS).

    Outlier days (e.g. large market dislocations) receive lower weights,
    reducing their influence on the estimated components.  The weight function
    is based on the Mahalanobis distance of each observation from the current
    model fit.

    This is particularly relevant for vol surfaces where a handful of stress
    events (Lehman, COVID, etc.) can dominate the sample covariance.

    Parameters
    ----------
    n_components : int
    n_iter : int
        Number of reweighting iterations.
    weight_fn : str
        ``'bisquare'`` – Tukey bisquare (hard zero beyond cutoff).
        ``'huber'``    – Huber weights (soft downweighting).
        ``'cauchy'``   – Cauchy/Lorentzian (very robust, heavier tails).
    cutoff_sigma : float
        Threshold in Mahalanobis distance units beyond which weights shrink.
    init_estimator : str
        Initial covariance estimator (``'sample'`` or ``'mcd'``).
    """

    def __init__(
        self,
        n_components:   int   = 5,
        n_iter:         int   = 10,
        weight_fn:      str   = 'bisquare',
        cutoff_sigma:   float = 3.0,
        init_estimator: str   = 'sample',
    ):
        super().__init__(n_components)
        self.n_iter         = n_iter
        self.weight_fn      = weight_fn
        self.cutoff_sigma   = cutoff_sigma
        self.init_estimator = init_estimator
        self.weights_:      Optional[np.ndarray] = None

    def fit(self, X: np.ndarray) -> 'RobustPCAModel':
        n, p   = X.shape
        k      = self.n_components
        w      = np.ones(n)          # initial uniform weights

        for iteration in range(self.n_iter):
            # Weighted mean and covariance
            w_sum    = w.sum()
            mu       = (w[:, None] * X).sum(axis=0) / w_sum
            Xc       = X - mu
            cov      = (w[:, None] * Xc).T @ Xc / w_sum

            vals, vecs = _eigh_sorted(cov)
            comps    = vecs[:, :k]

            # Mahalanobis distance via PC projection
            proj     = Xc @ comps                 # (n, k)
            ev_trunc = _clip_eigenvalues(vals[:k])
            # Squared Mahalanobis in the k-dim PC subspace
            mah2     = (proj**2 / ev_trunc).sum(axis=1)  # (n,)
            mah      = np.sqrt(np.maximum(mah2, 0))

            # Recompute weights
            c   = self.cutoff_sigma
            u   = mah / c
            w   = self._weight(u)
            w   = np.maximum(w, 1e-6)

        self._mean        = mu
        self._components  = comps
        self._eigenvalues = _clip_eigenvalues(vals[:k])
        self.weights_     = w
        return self

    def _weight(self, u: np.ndarray) -> np.ndarray:
        fn = self.weight_fn.lower()
        if fn == 'bisquare':
            w = np.where(u <= 1.0, (1.0 - u**2)**2, 0.0)
        elif fn == 'huber':
            w = np.where(u <= 1.0, 1.0, 1.0 / u)
        elif fn == 'cauchy':
            w = 1.0 / (1.0 + u**2)
        else:
            raise ValueError(f"Unknown weight function '{self.weight_fn}'.")
        return w

    def outlier_days(self, threshold: float = 0.1) -> np.ndarray:
        """Return boolean mask of observations identified as outliers (low weight)."""
        if self.weights_ is None:
            raise RuntimeError("Call fit() first.")
        return self.weights_ < threshold


# ═══════════════════════════════════════════════════════════════════════════════
# Factory / Registry
# ═══════════════════════════════════════════════════════════════════════════════
_MODEL_REGISTRY = {
    'static':          StaticPCA,
    'rolling':         RollingPCA,
    'online':          OnlinePCA,
    'sparse':          SparsePCAModel,
    'ppca':            PPCAModel,
    'factor_analysis': FactorAnalysisModel,
    'robust':          RobustPCAModel,
}


def get_model(name: str, **kwargs) -> BasePCA:
    """
    Instantiate a PCA model by name.

    Parameters
    ----------
    name : str
        One of: ``'static'``, ``'rolling'``, ``'online'``, ``'sparse'``,
        ``'ppca'``, ``'factor_analysis'``, ``'robust'``.
    **kwargs
        Forwarded to the model constructor.

    Examples
    --------
    >>> model = get_model('rolling', n_components=3, window=200)
    >>> model = get_model('static',  n_components=5, cov_estimator='ewma',
    ...                              half_life=60)
    """
    key = name.lower().replace('-', '_').replace(' ', '_')
    if key not in _MODEL_REGISTRY:
        raise ValueError(
            f"Unknown model '{name}'. Available: {list(_MODEL_REGISTRY.keys())}"
        )
    return _MODEL_REGISTRY[key](**kwargs)


def available_models() -> list:
    return list(_MODEL_REGISTRY.keys())
