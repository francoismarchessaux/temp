"""
covariance.py
=============
Covariance matrix estimators for PCA on volatility surfaces.

Each estimator exposes a common interface::

    est = SomeEstimator(**params)
    cov = est.fit(X)     # X : (n_obs, n_features)

Available estimators
--------------------
``sample``          – classical sample covariance (MLE)
``ledoit_wolf``     – Oracle-Approximating Shrinkage (Ledoit & Wolf 2004,
                      sklearn auto-tuned intensity)
``oas``             – Oracle Approximating Shrinkage (Chen et al. 2010)
``ewma``            – Exponentially Weighted Moving Average (λ or half_life)
``mcd``             – Minimum Covariance Determinant (robust, Rousseeuw 1984)
``graphical_lasso`` – ℓ1-penalised precision matrix (Friedman et al. 2008)
``factor_model``    – low-rank + diagonal (Bai-Ng / Fan et al.)

Factory
-------
    from covariance import get_estimator
    est = get_estimator('ewma', half_life=60)
    cov = est.fit(X)
"""

from __future__ import annotations

import numpy as np
from abc import ABC, abstractmethod
from typing import Optional
from sklearn.covariance import (
    LedoitWolf,
    OAS,
    MinCovDet,
    GraphicalLassoCV,
)


# ── Base class ────────────────────────────────────────────────────────────────
class BaseCovarianceEstimator(ABC):
    """Abstract base: ``fit(X)`` returns a (p, p) positive-definite matrix."""

    @abstractmethod
    def fit(self, X: np.ndarray) -> np.ndarray:
        """
        Parameters
        ----------
        X : np.ndarray, shape (n_obs, n_features)
            Centred or raw observations.  Centering is handled internally.

        Returns
        -------
        cov : np.ndarray, shape (n_features, n_features)
        """

    def __repr__(self) -> str:
        return self.__class__.__name__


# ── 1. Sample covariance ──────────────────────────────────────────────────────
class SampleCovariance(BaseCovarianceEstimator):
    """
    Classical unbiased sample covariance  Σ = X'X / (n-1)  after centering.
    """

    def fit(self, X: np.ndarray) -> np.ndarray:
        Xc = X - X.mean(axis=0)
        n  = Xc.shape[0]
        return (Xc.T @ Xc) / (n - 1)


# ── 2. Ledoit-Wolf shrinkage ──────────────────────────────────────────────────
class LedoitWolfCovariance(BaseCovarianceEstimator):
    """
    Ledoit-Wolf analytical shrinkage towards a scaled identity matrix.
    Shrinkage intensity α is determined analytically (no cross-validation).

    Ledoit, O., & Wolf, M. (2004). A well-conditioned estimator for
    large-dimensional covariance matrices.
    """

    def __init__(self, store_shrinkage: bool = True):
        self.store_shrinkage = store_shrinkage
        self.shrinkage_: Optional[float] = None

    def fit(self, X: np.ndarray) -> np.ndarray:
        lw = LedoitWolf().fit(X)
        if self.store_shrinkage:
            self.shrinkage_ = lw.shrinkage_
        return lw.covariance_


# ── 3. OAS shrinkage ─────────────────────────────────────────────────────────
class OASCovariance(BaseCovarianceEstimator):
    """
    Oracle Approximating Shrinkage estimator.
    Outperforms Ledoit-Wolf when n/p is small.

    Chen, Y., Wiesel, A., Eldar, Y. C., & Hero, A. O. (2010).
    """

    def __init__(self, store_shrinkage: bool = True):
        self.store_shrinkage = store_shrinkage
        self.shrinkage_: Optional[float] = None

    def fit(self, X: np.ndarray) -> np.ndarray:
        oas = OAS().fit(X)
        if self.store_shrinkage:
            self.shrinkage_ = oas.shrinkage_
        return oas.covariance_


# ── 4. EWMA covariance ────────────────────────────────────────────────────────
class EWMACovariance(BaseCovarianceEstimator):
    """
    Exponentially Weighted Moving Average covariance.

    Weights: w_t = λ^(T-t),  t = 1 … T
    Normalised so that Σ w_t = 1.

    Parameters
    ----------
    half_life : float or None
        Half-life in *observations* (e.g. 60 for 60-day half-life on daily data).
        Mutually exclusive with ``lam``.
    lam : float or None
        Decay factor λ ∈ (0, 1).  Mutually exclusive with ``half_life``.
    min_obs : int
        Minimum number of observations required.

    Notes
    -----
    half_life  ↔  λ  relationship:   λ = 0.5^(1/half_life)
    RiskMetrics daily standard: half_life ≈ 75 (λ ≈ 0.94).
    """

    def __init__(
        self,
        half_life:  Optional[float] = None,
        lam:        Optional[float] = None,
        min_obs:    int             = 10,
    ):
        if (half_life is None) == (lam is None):
            raise ValueError("Specify exactly one of `half_life` or `lam`.")
        self.half_life = half_life
        self.lam       = lam if lam is not None else 0.5 ** (1.0 / half_life)
        self.min_obs   = min_obs

    def fit(self, X: np.ndarray) -> np.ndarray:
        n, p = X.shape
        if n < self.min_obs:
            raise ValueError(f"Need ≥ {self.min_obs} obs, got {n}.")

        # Weights: most recent observation (last row) has weight λ^0 = 1
        exp = np.arange(n - 1, -1, -1, dtype=float)   # n-1, n-2, …, 0
        w   = self.lam ** exp
        w  /= w.sum()

        # Weighted mean
        mu  = (w[:, None] * X).sum(axis=0)
        Xc  = X - mu

        # Weighted outer products
        cov = (w[:, None] * Xc).T @ Xc
        return cov

    def __repr__(self) -> str:
        lam_str = f"λ={self.lam:.4f}"
        hl_str  = f", half_life={self.half_life}" if self.half_life else ""
        return f"EWMACovariance({lam_str}{hl_str})"


# ── 5. MCD (robust) ──────────────────────────────────────────────────────────
class MCDCovariance(BaseCovarianceEstimator):
    """
    Minimum Covariance Determinant – robust to outliers / stress events.
    Finds the subset of h ≥ n/2 observations with the smallest determinant
    and computes the classical covariance on that subset.

    Parameters
    ----------
    support_fraction : float or None
        Fraction of observations to include (h/n).  Defaults to sklearn's
        choice (roughly 0.75 + p/(4n)).
    random_state : int
    """

    def __init__(
        self,
        support_fraction: Optional[float] = None,
        random_state: int = 0,
    ):
        self.support_fraction = support_fraction
        self.random_state     = random_state
        self.support_mask_: Optional[np.ndarray] = None

    def fit(self, X: np.ndarray) -> np.ndarray:
        mcd = MinCovDet(
            support_fraction=self.support_fraction,
            random_state=self.random_state,
        ).fit(X)
        self.support_mask_ = mcd.support_
        return mcd.covariance_


# ── 6. Graphical Lasso ────────────────────────────────────────────────────────
class GraphicalLassoCovariance(BaseCovarianceEstimator):
    """
    ℓ1-penalised precision matrix (inverse covariance).
    Encourages sparsity in the precision matrix, meaning many pairs of
    pillars are conditionally independent given the rest.
    α is chosen by cross-validation (GraphicalLassoCV).

    Useful when the surface has localised factor structure (e.g. front-end
    and back-end move independently conditional on the level factor).
    """

    def __init__(self, cv: int = 5, n_jobs: int = 1):
        self.cv     = cv
        self.n_jobs = n_jobs
        self.alpha_: Optional[float] = None

    def fit(self, X: np.ndarray) -> np.ndarray:
        gl = GraphicalLassoCV(cv=self.cv, n_jobs=self.n_jobs).fit(X)
        self.alpha_ = gl.alpha_
        return gl.covariance_


# ── 7. Factor-model shrinkage (Bai-Ng / Fan et al.) ──────────────────────────
class FactorModelCovariance(BaseCovarianceEstimator):
    """
    Low-rank + diagonal covariance estimator.

    Σ = B B' + D
    where B (n_features × n_factors) is estimated by PC regression and
    D is the diagonal of residual variances.

    This is the covariance implied by a strict factor model and is always
    positive definite.  It is well-suited to vol surfaces where a small
    number of factors explain most of the variance.

    Parameters
    ----------
    n_factors : int
        Number of common factors to retain.
    noise_floor : float
        Minimum diagonal value (avoids degenerate precision matrices).
    """

    def __init__(self, n_factors: int = 5, noise_floor: float = 1e-4):
        self.n_factors   = n_factors
        self.noise_floor = noise_floor
        self.loadings_:  Optional[np.ndarray] = None
        self.idio_var_:  Optional[np.ndarray] = None

    def fit(self, X: np.ndarray) -> np.ndarray:
        n, p = X.shape
        Xc   = X - X.mean(axis=0)
        k    = min(self.n_factors, p, n - 1)

        # PCA on sample covariance
        S      = (Xc.T @ Xc) / (n - 1)
        vals, vecs = np.linalg.eigh(S)
        idx    = np.argsort(vals)[::-1]
        vals, vecs = vals[idx], vecs[:, idx]

        # Factor loadings: B = V_k * sqrt(Λ_k)
        self.loadings_ = vecs[:, :k] * np.sqrt(np.maximum(vals[:k], 0))

        # Idiosyncratic variances = diag(S - B B')
        common_cov = self.loadings_ @ self.loadings_.T
        idio       = np.diag(S) - np.diag(common_cov)
        self.idio_var_ = np.maximum(idio, self.noise_floor)

        # Reconstruct
        return common_cov + np.diag(self.idio_var_)


# ── Factory ───────────────────────────────────────────────────────────────────
_REGISTRY = {
    'sample':          SampleCovariance,
    'ledoit_wolf':     LedoitWolfCovariance,
    'oas':             OASCovariance,
    'ewma':            EWMACovariance,
    'mcd':             MCDCovariance,
    'graphical_lasso': GraphicalLassoCovariance,
    'factor_model':    FactorModelCovariance,
}


def get_estimator(name: str, **kwargs) -> BaseCovarianceEstimator:
    """
    Instantiate a covariance estimator by name.

    Parameters
    ----------
    name : str
        One of: ``'sample'``, ``'ledoit_wolf'``, ``'oas'``, ``'ewma'``,
        ``'mcd'``, ``'graphical_lasso'``, ``'factor_model'``.
    **kwargs
        Passed to the estimator constructor.

    Examples
    --------
    >>> est = get_estimator('ewma', half_life=60)
    >>> cov = est.fit(X)
    """
    name_l = name.lower().replace('-', '_').replace(' ', '_')
    if name_l not in _REGISTRY:
        raise ValueError(
            f"Unknown estimator '{name}'. "
            f"Available: {list(_REGISTRY.keys())}"
        )
    return _REGISTRY[name_l](**kwargs)


def available_estimators() -> list:
    return list(_REGISTRY.keys())
