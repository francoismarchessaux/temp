"""
data_generator.py
=================
Synthetic swaption ATM normal volatility surface generator.

Surface is driven by 3 latent factors with realistic dynamics:
    PC1 : parallel level shift  (~70% of variance)
    PC2 : expiry slope          (~15% of variance)
    PC3 : curvature             (~8%  of variance)
plus idiosyncratic noise and occasional jump events.

Output units throughout: ATM normal vol in **bps**.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Tuple, List

# ── Grid ─────────────────────────────────────────────────────────────────────
EXPIRIES      = ['1M', '3M', '6M', '1Y', '2Y', '5Y', '10Y']
TENORS        = ['1Y', '2Y', '5Y', '10Y', '20Y', '30Y']
EXPIRY_YEARS  = np.array([1/12, 3/12, 6/12, 1., 2., 5., 10.])
TENOR_YEARS   = np.array([1., 2., 5., 10., 20., 30.])
N_EXPIRY      = len(EXPIRIES)
N_TENOR       = len(TENORS)
N_PILLARS     = N_EXPIRY * N_TENOR   # 42


# ── Public helpers ────────────────────────────────────────────────────────────
def pillar_names() -> List[str]:
    """Return list of pillar labels, e.g. '1Mx1Y', '10Yx30Y'."""
    return [f'{e}x{t}' for e in EXPIRIES for t in TENORS]


def surface_to_matrix(s: pd.Series) -> pd.DataFrame:
    """Reshape a flattened surface Series to (N_EXPIRY × N_TENOR) DataFrame."""
    return pd.DataFrame(s.values.reshape(N_EXPIRY, N_TENOR),
                        index=EXPIRIES, columns=TENORS)


def matrix_to_surface(df: pd.DataFrame) -> pd.Series:
    """Flatten a (expiry × tenor) DataFrame to a Series with pillar labels."""
    return pd.Series(df.values.flatten(), index=pillar_names())


# ── Internal helpers ──────────────────────────────────────────────────────────
def _base_surface() -> np.ndarray:
    """
    Realistic base ATM normal vol surface (bps).
    Vol declines with expiry (mean-reversion effect) and rises slightly with tenor.
    """
    # Expiry dimension: high short-end, decaying with log(expiry)
    level = 130 - 45 * np.log1p(EXPIRY_YEARS) / np.log1p(EXPIRY_YEARS[-1])
    # Tenor dimension: mild positive slope (steepener premium)
    slope = 1.0 + 0.06 * np.log1p(TENOR_YEARS) / np.log1p(TENOR_YEARS[-1])
    return np.outer(level, slope)   # (N_EXPIRY, N_TENOR)


def _build_factor_loadings() -> np.ndarray:
    """
    Construct interpretable PCA factor loading vectors on the flattened surface.

    Returns
    -------
    loadings : np.ndarray, shape (N_PILLARS, 3)
        Unit-norm loading vectors for [PC1_level, PC2_slope, PC3_curvature].
    """
    exp_idx = np.arange(N_PILLARS) // N_TENOR
    ten_idx = np.arange(N_PILLARS) %  N_TENOR

    exp_norm = np.log1p(EXPIRY_YEARS[exp_idx]) / np.log1p(EXPIRY_YEARS[-1])
    ten_norm = np.log1p(TENOR_YEARS[ten_idx])  / np.log1p(TENOR_YEARS[-1])

    # PC1 – parallel shift: nearly flat, slight taper at long end
    pc1 = 1.0 - 0.15 * exp_norm - 0.05 * ten_norm

    # PC2 – expiry slope: short expiry up, long expiry down
    pc2 = 0.8 * (0.5 - exp_norm) + 0.25 * (0.5 - ten_norm)

    # PC3 – curvature: U-shape across expiries
    pc3 = np.cos(np.pi * exp_norm) * 0.7 + 0.2 * np.cos(np.pi * ten_norm)

    loadings = np.stack([pc1, pc2, pc3], axis=1)   # (N_PILLARS, 3)
    loadings /= np.linalg.norm(loadings, axis=0, keepdims=True)
    return loadings


def _build_vega(seed: int = 0) -> np.ndarray:
    """
    Synthetic vega book (USD per 1 bps move per pillar).

    Typical structure:
      - Long vol on short expiries (gamma-rich options)
      - Short vol on mid-expiry, mid-tenor (hedged bucket)
      - Roughly flat on long end
    """
    rng = np.random.default_rng(seed)

    # Base magnitude: $50k per bps for 1M expiry, decaying
    base_mag = 50_000 / (1.0 + 3.0 * EXPIRY_YEARS[:, None]**0.5)

    # Sign structure: replicate a realistically mixed book
    signs = np.ones((N_EXPIRY, N_TENOR))
    signs[2:5, 1:4] = -1.0   # short mid-exp / mid-tenor
    signs[5:,  :]   =  0.4   # light long-end

    # Small random perturbation
    signs += 0.3 * rng.normal(size=(N_EXPIRY, N_TENOR))
    signs  = np.sign(signs)

    return (base_mag * signs).flatten()


# ── Main generator ────────────────────────────────────────────────────────────
def generate_vol_surface_data(
    n_days:       int   = 500,
    seed:         int   = 42,
    factor_vols:  Tuple[float, float, float] = (8.0, 3.5, 1.8),
    noise_vol:    float = 0.6,
    include_jumps: bool = True,
    jump_prob:    float = 0.025,
    jump_scale:   float = 18.0,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series]:
    """
    Generate a synthetic daily swaption ATM normal vol surface dataset.

    Parameters
    ----------
    n_days : int
        Number of trading days (level observations); changes has n_days-1 rows.
    seed : int
        RNG seed for reproducibility.
    factor_vols : (float, float, float)
        Daily standard deviation (bps) for each of the 3 latent factors.
    noise_vol : float
        Daily idiosyncratic vol (bps) per pillar, independent across pillars.
    include_jumps : bool
        Whether to inject occasional large parallel shocks.
    jump_prob : float
        Probability of a jump on any given day.
    jump_scale : float
        Magnitude (bps std-dev) of jump events.

    Returns
    -------
    surfaces : pd.DataFrame  (n_days × N_PILLARS)
        Vol surface levels in bps.
    changes : pd.DataFrame  ((n_days-1) × N_PILLARS)
        Daily first differences in bps.
    vega : pd.Series  (N_PILLARS,)
        Vega sensitivities in USD/bps.
    """
    rng      = np.random.default_rng(seed)
    loadings = _build_factor_loadings()         # (N_PILLARS, 3)
    base     = _base_surface().flatten()        # (N_PILLARS,)

    # ── Factor returns ────────────────────────────────────────────────────
    raw_factors = rng.normal(0.0, 1.0, size=(n_days - 1, 3))
    factor_rets  = raw_factors * np.array(factor_vols)

    # Optional jumps injected into the level factor (PC1)
    if include_jumps:
        mask = rng.random(n_days - 1) < jump_prob
        jumps = rng.normal(0.0, jump_scale, size=n_days - 1) * mask
        factor_rets[:, 0] += jumps

    # ── Pillar changes ────────────────────────────────────────────────────
    noise          = rng.normal(0.0, noise_vol, size=(n_days - 1, N_PILLARS))
    pillar_changes = factor_rets @ loadings.T + noise   # (n_days-1, N_PILLARS)

    # ── Integrate to get levels ───────────────────────────────────────────
    surfaces = np.empty((n_days, N_PILLARS))
    surfaces[0] = base
    for t in range(1, n_days):
        surfaces[t] = np.maximum(surfaces[t - 1] + pillar_changes[t - 1], 5.0)

    # ── Pack into DataFrames ──────────────────────────────────────────────
    cols     = pillar_names()
    idx_all  = pd.bdate_range('2020-01-01', periods=n_days)

    df_surfaces = pd.DataFrame(surfaces,       index=idx_all,    columns=cols)
    df_changes  = pd.DataFrame(pillar_changes, index=idx_all[1:], columns=cols)
    vega        = pd.Series(_build_vega(), index=cols, name='vega_usd_per_bps')

    return df_surfaces, df_changes, vega
