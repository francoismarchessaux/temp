# PCA models for swaption vega projection — empirical comparison

**Setup.** Synthetic ATM normal-vol surface, 7 expiries × 6 tenors = 42 buckets,
2520 daily observations (~10y) generated from 4 latent shape factors
(level / expiry-slope / tenor-slope / twist) + idiosyncratic noise, with a
**vol-of-vol regime shift at day 1260** (idio noise also rises ~40%). Vega
book is concentrated in the 6m–2y × 5y–10y region, mixed sign, total
|vega| ≈ $423k/bp, daily PnL std ≈ $440k. Code in this directory is the
end-to-end pipeline; you should swap the synthetic data layer for your real
surface history and re-run.

---

## 1. Head-to-head, full sample, k = 4

| Model      |  R²(PnL) | Tracking err ($/d) | Max abs err ($) | Notes |
|-----------|---------:|-------------------:|----------------:|-------|
| Absolute   | 0.9876 |             48,914 |         171,000 | Baseline |
| Relative   | 0.9873 |             49,398 |         172,000 | Same R² but front-loads more risk into PC1 |
| Shrinkage  | 0.9876 |             48,914 |         171,000 | Identical to absolute (T/D=60 → α≈0) |
| Tucker     | 0.9876 |             48,949 |         175,000 | Match absolute with same effective rank |
| Vega-wgt   | 0.9842 |             55,258 |         232,000 | **Worse** on every metric |
| Liq-wgt    | 0.9842 |             55,400 |         219,000 | Worse here (synth has no extra wing noise; would help in real data) |

Translating the tracking error: absolute PCA leaves ~$49k/day of unexplained
PnL std, ~11% of total PnL std. The worst residual day is ~$171k.

## 2. Per-factor decomposition (absolute PCA)

| PC  | factor σ (bp) | β ($/factor) | PnL std contrib ($/d) | ρ (book share) | cum R² PnL |
|----:|--------------:|-------------:|----------------------:|---------------:|-----------:|
| 1   | 45.9          | -9.07k       | 416,000               | 0.910          | 0.899 |
| 2   | 19.3          | +6.71k       | 129,000               | 0.088          | 0.985 |
| 3   | 12.8          | +1.55k       |  19,900               | 0.002          | 0.987 |
| 4   |  8.1          | -0.16k       |   1,300               | 9·10⁻⁶         | 0.987 |

PC1 (level) explains 91% of book risk by itself. PC2 (expiry slope) takes
us from 90% to 98.5%. After PC3 there is essentially no marginal book PnL
to explain. This is your selection rule: **rank by ρ_i, not by surface
variance share**, and stop where ρ falls below your tolerance (here ~10⁻³).

The contrast is in `07_book_vs_surface_share.png`: surface variance shares
are 78 / 14 / 6 / 2%, but book variance shares are 91 / 9 / 0.2 / 0%. Your
book is more level-heavy than the surface — PC1 is *more* important to you
than the market would suggest.

## 3. Choosing k

`02_te_vs_k.png`. For abs / rel / shrink / tucker, the elbow is at k=2,
with marginal improvement to k=4, then a long flat plateau. **k = 3 or 4 is
the sweet spot.**

The vega-weighted model is qualitatively different: it improves through k=2
and then *deteriorates*, hitting R²=0.78 at k=8 (vs 0.99 for the others).
This is a textbook overfitting pathology — high-k weighted PCs find
directions that maximise variance in high-vega buckets, but those
directions become noise-dominated and project spuriously onto v.

## 4. Window length and out-of-sample stability

`03_te_vs_L.png` — OOS tracking error vs L (60-day rolling test blocks).

| L (days) | abs OOS TE | tucker OOS TE | wgt_v OOS TE |
|---------:|-----------:|--------------:|--------------:|
| 60       | 49,915 | 47,693 | 60,208 |
| 125      | 48,896 | 47,952 | 57,292 |
| 250      | 48,958 | 48,440 | 56,645 |
| 500      | 49,958 | 49,692 | 57,500 |
| 1250     | 55,404 | 55,211 | 64,154 |
| 2000     | 56,519 | 56,240 | 65,321 |

Two non-obvious findings:

1. **Long windows are not better.** L=125–250 is the sweet spot; L=2000
   is materially worse. The reason here is the regime shift at day 1260 —
   long windows blend pre- and post-regime covariances and fit neither
   well. **In real data, this generalises to: any structural change in
   vol dynamics (post-2008, post-COVID, post the 2022 rates regime shift)
   makes long windows actively harmful, not just stale.**

2. **Tucker has the lowest OOS error at short windows** (47.7k vs 49.9k for
   plain PCA at L=60). The separability constraint is a regulariser — fewer
   effective parameters means less overfitting. Worth keeping in your
   toolkit for periods when you suspect non-stationarity.

`04_loadings_abs.png` shows the eigenvectors are extremely stable across
windows: subspace angle of top-4 PCs vs full-sample reference is

| L     | mean angle (deg) | max angle (deg) |
|------:|-----------------:|----------------:|
|   60  | 2.89             | 4.44            |
|  125  | 1.87             | 2.31            |
|  250  | 1.34             | 1.71            |
|  500  | 0.86             | 1.07            |
| 1250  | 0.40             | 0.58            |

So the *shapes* are stable; what changes across windows is the
*eigenvalues* (factor variances) — i.e. how risky each factor is. This
matters for risk numbers and PnL-error variance prediction, but not for
PnL attribution itself.

## 5. Shrinkage

`09_lw_alpha.png` — Ledoit–Wolf optimal α vs L. With D = 42 and a
factor-driven SNR, α is small (≤ 0.06 even at L=42). Practical
implications:

- For your 42-bucket synthetic surface, shrinkage doesn't move the needle
  unless you go below ~3 months of history.
- If you grid finer (e.g. 12 expiries × 12 tenors = 144 buckets), the
  T/D ratio is much worse and α becomes meaningful. Rule of thumb:
  shrinkage matters when L < 3D. At D=144 and L=250, you're near α ≈ 0.1–0.2.
- For very short windows (one quarter), use shrinkage *and* prefer Tucker
  — both regularise. Don't trust raw PCA at L < 60d.

## 6. Per-bucket reliability

`05_per_bucket.png`. The R² heatmap shows ≥ 99% per-bucket variance
explained (high SNR in this synthetic). The right panel — PnL error std
contribution per bucket — concentrates *exactly* in the high-vega cells:
1Y/2Y × 5Y/10Y. That's mathematical, not informational: contribution is
$v_j^2 \cdot \mathrm{Var}(\varepsilon_j)$, so any leftover bucket-level
noise gets amplified by vega. The takeaway: **for this book the
unexplained risk is dominated by 6m–2y × 5y–10y idiosyncratic moves**,
which is also where the book sits. To reduce it further you'd add a
localised PC (sparse PCA) targeting that quadrant — not a fifth global PC.

## 7. The vega-weighting question (revisited with data)

Two empirical facts make the case:

- In-sample tracking error: 55k vs 49k (+13%) at k=4; **R² collapses to
  0.78 at k=8** (vs 0.99 for plain PCA).
- Out-of-sample tracking error: 57–60k vs 49–50k at every window length.

The mechanism: vega-weighted PCA finds directions $u$ that maximise
$u^\top \mathrm{diag}(v) C \mathrm{diag}(v) u$. At high k, the
maximum-variance directions in *that* metric are buckets where vega is
large but variance happens to be low — which gives them spuriously large
loadings in the unweighted space, and those loadings have nothing to do
with how vol actually moves. PC1 happens to look similar (both essentially
parallel level), but PCs 2–4 tilt toward where the book is, then PCs 5+
become noise.

**Defensible alternatives** to "I want my model to focus on what matters":

- Use plain PCA but rank PCs by $\rho_i = \lambda_i \beta_i^2 / \sum \lambda_j \beta_j^2$.
  This is the "book-aware" criterion *without* contaminating the basis.
  Already in `per_factor_table` as `rho_book_share`.
- If you really want a weighted covariance, weight by **liquidity / inverse
  bid-ask noise**. Defensible because it's book-independent.
- Use vega-weighted PCA only as a one-off **diagnostic snapshot** to
  identify your largest PnL concentration — not as your production factor
  model.

## 8. Recommendation

For a swaption vega book on this kind of surface:

1. **Production model:** absolute-Δσ PCA, k = 3 (k = 4 if PC4 has clear
   structural meaning on your surface), L = 250d (one trading year),
   refitted weekly. Add Ledoit–Wolf shrinkage if your grid is finer than
   ~50 buckets.
2. **Cross-check:** Tucker(2,2). Should agree on R² to within 1%. If it
   doesn't, you have non-separable structure worth investigating.
3. **Diagnostic, every refit:**
   - Per-factor table sorted by ρ — drop any PC with ρ < 0.005.
   - Per-bucket R² and per-bucket residual-std heatmaps. Flag buckets
     with R² < 0.95 — those vegas are unreliable to project.
   - PnL backtest: realised vs explained, with residual underneath. Watch
     for residual-std regime shifts (your tracking error is changing).
4. **Avoid:** vega-weighted PCA as a primary model. Use ρ-ranking instead.

## Files

- `data.py` — synthetic surface and book
- `models.py` — five PCA variants
- `diagnostics.py` — per-factor / per-bucket / summary tables
- `run_compare.py` — head-to-head comparison
- `run_sweep.py` — k and L hyperparameter sweep
- `run_plots.py` — all 9 figures
- `plots/*.png` — figures referenced above
