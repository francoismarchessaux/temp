"""PCA variants with a clean interface.

Each model returns a Result object with:
    U     (D, k)   loadings on the surface (orthonormal in the model's metric)
    beta  (k,)     reported $-vega per factor (at average vol, for the per-factor table)
    F     (T_eff, k)   raw factor scores (in the model's own units)
    pnl_contribution (T_eff, k)   per-factor PnL contribution in $/day
                                  -- summed across columns gives the reconstructed PnL
    name  str
    extras dict
    t_offset  number of days dropped from the front of X (e.g. 1 for relative PCA)
"""
from __future__ import annotations

import numpy as np
from numpy.linalg import eigh, svd
from dataclasses import dataclass, field


@dataclass
class Result:
    U: np.ndarray
    beta: np.ndarray
    F: np.ndarray
    pnl_contribution: np.ndarray
    name: str
    extras: dict = field(default_factory=dict)
    t_offset: int = 0


def _eig_topk(C, k):
    w, V = eigh(C)
    idx = np.argsort(w)[::-1]
    return w[idx[:k]], V[:, idx[:k]]


def _ledoit_wolf(X):
    T, D = X.shape
    Xc = X - X.mean(0, keepdims=True)
    S = Xc.T @ Xc / T
    mu = np.trace(S) / D
    target = mu * np.eye(D)
    d2 = np.sum((S - target) ** 2)
    b2 = 0.0
    for t in range(T):
        b2 += np.sum((np.outer(Xc[t], Xc[t]) - S) ** 2)
    b2 /= T ** 2
    b2 = min(b2, d2)
    alpha = b2 / d2 if d2 > 0 else 0.0
    return alpha * target + (1 - alpha) * S, alpha


def pca_absolute(V, X, Sigma, k):
    v = V.reshape(-1)
    Xc = X - X.mean(0)
    C = Xc.T @ Xc / (len(X) - 1)
    lam, U = _eig_topk(C, k)
    F = Xc @ U
    beta = v @ U
    pnl = F * beta
    return Result(U, beta, F, pnl, "abs", {"C": C, "lam": lam})


def pca_relative(V, X, Sigma, k):
    """PCA on Δσ/σ_{t-1} with time-varying betas in the projection.

    Convention: Sigma has length T or T+1.  We use σ_{t-1} as denominator;
    if Sigma is length T (same as X), we use Sigma itself (approximating).
    """
    v = V.reshape(-1)
    if len(Sigma) == len(X) + 1:
        sigma_lag = Sigma[:-1]
        X_use = X
    else:
        # Same length as X — use Sigma as denominator (small bias)
        sigma_lag = Sigma
        X_use = X
    Xrel = X_use / sigma_lag
    Xrel_c = Xrel - Xrel.mean(0)
    C = Xrel_c.T @ Xrel_c / (len(Xrel_c) - 1)
    lam, Urel = _eig_topk(C, k)
    F = Xrel_c @ Urel

    Beta_t = (v[None, :] * sigma_lag) @ Urel
    pnl = F * Beta_t

    sigma_bar = sigma_lag.mean(0)
    beta_report = (v * sigma_bar) @ Urel
    U_report = sigma_bar[:, None] * Urel
    Q, _ = np.linalg.qr(U_report)
    return Result(Q, beta_report, F, pnl, "rel",
                  {"Urel": Urel, "lam_rel": lam, "Beta_t": Beta_t,
                   "sigma_lag": sigma_lag},
                  t_offset=0)


def pca_weighted(V, X, Sigma, k, w, name="wgt"):
    v = V.reshape(-1)
    w = np.asarray(w, float)
    sw = np.sqrt(w)
    Xc = X - X.mean(0)
    Y = Xc * sw
    C = Y.T @ Y / (len(X) - 1)
    lam, Vw = _eig_topk(C, k)
    U = Vw / sw[:, None]
    norms = np.linalg.norm(U, axis=0)
    U = U / norms
    F = Xc @ U
    beta = v @ U
    pnl = F * beta
    return Result(U, beta, F, pnl, name, {"w": w, "lam": lam})


def pca_shrinkage(V, X, Sigma, k):
    v = V.reshape(-1)
    Chat, alpha = _ledoit_wolf(X)
    lam, U = _eig_topk(Chat, k)
    F = (X - X.mean(0)) @ U
    beta = v @ U
    pnl = F * beta
    return Result(U, beta, F, pnl, "shrink", {"alpha": alpha, "lam": lam})


def pca_tucker(V, X, Sigma, M, N, k_e, k_t):
    v = V.reshape(-1)
    T = len(X)
    Xc = X - X.mean(0)
    Xt = Xc.reshape(T, M, N)
    U1 = Xt.transpose(1, 0, 2).reshape(M, T * N)
    A, _, _ = svd(U1, full_matrices=False); A = A[:, :k_e]
    U2 = Xt.transpose(2, 0, 1).reshape(N, T * M)
    B, _, _ = svd(U2, full_matrices=False); B = B[:, :k_t]
    K = k_e * k_t
    U = np.zeros((M * N, K))
    for i in range(k_e):
        for j in range(k_t):
            U[:, i * k_t + j] = np.outer(A[:, i], B[:, j]).reshape(-1)
    Q, _ = np.linalg.qr(U)
    F = Xc @ Q
    beta = v @ Q
    pnl = F * beta
    return Result(Q, beta, F, pnl, "tucker", {"A": A, "B": B})
